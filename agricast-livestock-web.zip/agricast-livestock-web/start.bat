@echo off
REM Starts the API (5050) and the website (5080). Close both windows to stop.
cd /d "%~dp0"
start "Agricast API" cmd /k dotnet run --project backend-aspnet\AgricastLivestock.Api
start "Agricast Web" cmd /k dotnet run --project web-aspnet\AgricastLivestock.Web
timeout /t 6 >nul
start http://localhost:5080
