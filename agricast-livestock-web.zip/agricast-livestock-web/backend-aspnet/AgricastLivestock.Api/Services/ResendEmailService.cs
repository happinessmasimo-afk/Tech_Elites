using System.Net.Http.Json;
using System.Text.Json;
using AgricastLivestock.Api.Models;
using Microsoft.Extensions.Options;

namespace AgricastLivestock.Api.Services;

/// <summary>
/// Sends email through Resend's REST API (https://resend.com). Used for
/// purchase slips. Account confirmation and password-reset emails are sent
/// by Supabase Auth itself, which you point at Resend's SMTP server (see
/// README) so those use the same sender.
/// </summary>
public class ResendEmailService
{
    private readonly IHttpClientFactory _factory;
    private readonly ResendOptions _options;
    private readonly ILogger<ResendEmailService> _logger;

    public ResendEmailService(IHttpClientFactory factory, IOptions<ResendOptions> options, ILogger<ResendEmailService> logger)
    {
        _factory = factory;
        _options = options.Value;
        _logger = logger;
    }

    public bool IsConfigured => !string.IsNullOrWhiteSpace(_options.ApiKey);

    public async Task<(bool ok, string error)> SendAsync(string to, string subject, string html)
    {
        if (!IsConfigured) return (false, "Email is not set up yet. Add your Resend API key to the API's appsettings.");

        var request = new HttpRequestMessage(HttpMethod.Post, "https://api.resend.com/emails")
        {
            Content = JsonContent.Create(new { from = _options.From, to = new[] { to }, subject, html })
        };
        request.Headers.Add("Authorization", $"Bearer {_options.ApiKey}");
        // Resend rejects requests without a User-Agent header.
        request.Headers.UserAgent.ParseAdd("AgricastLivestockApi/1.0");

        try
        {
            var client = _factory.CreateClient();
            var response = await client.SendAsync(request);
            var body = await response.Content.ReadAsStringAsync();
            if (response.IsSuccessStatusCode) return (true, "");

            _logger.LogWarning("Resend refused an email to {To}: {Status} {Body}", to, (int)response.StatusCode, body);
            return (false, ExtractMessage(body));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not reach Resend while emailing {To}", to);
            return (false, "Could not reach the email service. Try again in a moment.");
        }
    }

    private static string ExtractMessage(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("message", out var m) && m.ValueKind == JsonValueKind.String)
                return m.GetString() ?? "The email could not be sent.";
        }
        catch (JsonException) { /* fall through */ }
        return "The email could not be sent.";
    }
}
