using AgricastLivestock.Api.Models;

namespace AgricastLivestock.Api.Services;

/// <summary>Builds the purchase slip for a paid order and emails it. Reads
/// use the caller's own token, so row-level security decides who may see an
/// order: only its buyer and the owner of its listing can get a slip.</summary>
public class ReceiptService
{
    private readonly SupabaseRestService _rest;
    private readonly ResendEmailService _email;

    public ReceiptService(SupabaseRestService rest, ResendEmailService email)
    {
        _rest = rest;
        _email = email;
    }

    public async Task<(bool ok, int status, string error, ReceiptDto? receipt)> BuildAsync(
        string token, string userId, string? userEmail, string offerId)
    {
        var (offerOk, offerError, offer) = await _rest.GetOfferAsync(token, offerId);
        if (!offerOk) return (false, 502, offerError, null);
        if (offer is null) return (false, 404, "Order not found.", null);
        if (offer.PaymentStatus != "paid") return (false, 400, "This order has not been paid yet.", null);

        var (listingOk, listingError, listing) = await _rest.GetListingAsync(token, offer.ListingId);
        if (!listingOk) return (false, 502, listingError, null);
        if (listing is null) return (false, 404, "Listing not found.", null);

        var isBuyer = offer.BuyerId == userId;
        var isSeller = listing.OwnerId == userId;
        if (!isBuyer && !isSeller) return (false, 403, "This order is not yours.", null);

        string? sellerName = null;
        if (isSeller)
        {
            // Profiles are only readable by their owner, so the seller's
            // name is known on the seller's own copy only.
            var profile = await _rest.GetProfileAsync(token, userId);
            sellerName = profile?.FullName;
        }

        var (deliveryOk, _, delivery) = await _rest.GetDeliveryByOfferAsync(token, offerId);

        var idText = (offer.Id ?? offerId).Replace("-", "");
        var slip = "AGC-" + idText.Substring(0, Math.Min(8, idText.Length)).ToUpperInvariant();

        var receipt = new ReceiptDto
        {
            SlipNumber = slip,
            OfferId = offer.Id ?? offerId,
            IssuedAt = listing.SoldAt ?? offer.CreatedAt ?? DateTimeOffset.UtcNow,
            ViewerRole = isSeller ? "seller" : "buyer",
            BuyerName = offer.BuyerName ?? "Buyer",
            BuyerPhone = offer.BuyerPhone,
            BuyerEmail = isBuyer ? userEmail : null,
            SellerName = sellerName,
            ItemTitle = listing.Title,
            Species = listing.Species,
            Breed = listing.Breed,
            Sex = listing.Sex,
            Quantity = listing.Quantity,
            ItemLocation = listing.Location,
            PriceUnit = listing.PriceUnit,
            UnitPrice = listing.AskingPrice,
            AmountPaid = offer.OfferPrice ?? listing.AskingPrice
        };

        if (deliveryOk && delivery is not null)
        {
            receipt.FulfilmentMethod = delivery.Method;
            receipt.FulfilmentStatus = delivery.Status;
            if (delivery.Method == "delivery")
            {
                receipt.FulfilmentLatitude = delivery.BuyerLatitude;
                receipt.FulfilmentLongitude = delivery.BuyerLongitude;
            }
            else
            {
                receipt.FulfilmentLatitude = delivery.FarmerLatitude;
                receipt.FulfilmentLongitude = delivery.FarmerLongitude;
            }
        }

        return (true, 200, "", receipt);
    }

    public async Task<(bool ok, string error)> EmailAsync(ReceiptDto receipt, string toEmail)
    {
        var subject = (receipt.ViewerRole == "seller" ? "Your sale slip " : "Your purchase slip ") + receipt.SlipNumber;
        return await _email.SendAsync(toEmail, subject, EmailTemplates.Receipt(receipt));
    }
}
