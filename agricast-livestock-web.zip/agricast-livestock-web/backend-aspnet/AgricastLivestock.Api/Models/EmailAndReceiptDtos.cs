namespace AgricastLivestock.Api.Models;

/// <summary>Bound from the "Resend" section of appsettings / env vars. The
/// API key is a secret: keep it in appsettings.Development.json or an
/// environment variable (Resend__ApiKey), never in the website code.</summary>
public class ResendOptions
{
    public const string SectionName = "Resend";

    public string ApiKey { get; set; } = string.Empty;
    /// <summary>Sender shown on emails. Until you verify your own domain in
    /// Resend, use their test sender "onboarding@resend.dev".</summary>
    public string From { get; set; } = "Agricast Livestock <onboarding@resend.dev>";
}

/// <summary>Where the website lives. Used as the "redirect_to" address in
/// confirmation and password-reset emails so the links open the web app.</summary>
public class WebAppOptions
{
    public const string SectionName = "Web";

    public string BaseUrl { get; set; } = "http://localhost:5080";
}

public record ForgotPasswordRequest(string Email);

public record ResetPasswordRequest(string NewPassword);

/// <summary>A purchase slip for one paid order. Built from the offer, the
/// listing and the delivery, so it needs no extra database table.</summary>
public class ReceiptDto
{
    public string SlipNumber { get; set; } = string.Empty;
    public string OfferId { get; set; } = string.Empty;
    public DateTimeOffset IssuedAt { get; set; }
    /// <summary>"buyer" or "seller": whose copy this is.</summary>
    public string ViewerRole { get; set; } = "buyer";

    public string BuyerName { get; set; } = string.Empty;
    public string? BuyerPhone { get; set; }
    public string? BuyerEmail { get; set; }
    public string? SellerName { get; set; }

    public string ItemTitle { get; set; } = string.Empty;
    public string Species { get; set; } = string.Empty;
    public string? Breed { get; set; }
    public string? Sex { get; set; }
    public int Quantity { get; set; } = 1;
    public string? ItemLocation { get; set; }
    public string PriceUnit { get; set; } = "per_head";
    public decimal UnitPrice { get; set; }
    public decimal AmountPaid { get; set; }

    /// <summary>"pickup" or "delivery"; null if the buyer hasn't chosen yet.</summary>
    public string? FulfilmentMethod { get; set; }
    public string? FulfilmentStatus { get; set; }
    /// <summary>Delivery: the buyer's pinned address. Pickup: the farm.</summary>
    public double? FulfilmentLatitude { get; set; }
    public double? FulfilmentLongitude { get; set; }
}
