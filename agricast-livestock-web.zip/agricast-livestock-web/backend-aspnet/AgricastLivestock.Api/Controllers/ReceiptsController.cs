using System.Security.Claims;
using AgricastLivestock.Api.Models;
using AgricastLivestock.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AgricastLivestock.Api.Controllers;

/// <summary>Purchase slips: every paid order has one, for the buyer and for
/// the farmer who sold it.</summary>
[ApiController]
[Route("api/receipts")]
[Authorize]
public class ReceiptsController : ControllerBase
{
    private readonly ReceiptService _receipts;

    public ReceiptsController(ReceiptService receipts) => _receipts = receipts;

    [HttpGet("{offerId}")]
    public async Task<IActionResult> Get(string offerId)
    {
        var (token, userId, email) = Caller();
        var built = await _receipts.BuildAsync(token, userId, email, offerId);
        if (!built.ok) return StatusCode(built.status, new { error = built.error });
        return Ok(built.receipt);
    }

    /// <summary>Emails the slip to the logged-in user's own address.</summary>
    [HttpPost("{offerId}/email")]
    public async Task<IActionResult> Email(string offerId)
    {
        var (token, userId, email) = Caller();
        if (string.IsNullOrEmpty(email)) return BadRequest(new { error = "Your account has no email address." });

        var built = await _receipts.BuildAsync(token, userId, email, offerId);
        if (!built.ok || built.receipt is null) return StatusCode(built.status, new { error = built.error });

        var (sent, error) = await _receipts.EmailAsync(built.receipt, email);
        if (!sent) return StatusCode(502, new { error });
        return Ok(new { success = true, message = $"Slip sent to {email}." });
    }

    private (string token, string userId, string? email) Caller()
    {
        var token = HttpContext.Items["SupabaseAccessToken"] as string
            ?? throw new UnauthorizedAccessException("No Supabase access token on this request.");
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
            ?? throw new UnauthorizedAccessException("No user id claim on this request.");
        var email = User.FindFirst(ClaimTypes.Email)?.Value;
        return (token, userId, email);
    }
}
