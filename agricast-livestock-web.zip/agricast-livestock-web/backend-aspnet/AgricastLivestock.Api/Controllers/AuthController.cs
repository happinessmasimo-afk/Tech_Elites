using AgricastLivestock.Api.Models;
using AgricastLivestock.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace AgricastLivestock.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly SupabaseAuthService _auth;
    private readonly SupabaseRestService _rest;
    private readonly WebAppOptions _web;

    public AuthController(SupabaseAuthService auth, SupabaseRestService rest, IOptions<WebAppOptions> web)
    {
        _auth = auth;
        _rest = rest;
        _web = web.Value;
    }

    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest req)
    {
        var (ok, message, requiresConfirmation, token) =
            await _auth.SignUpAsync(req.Email, req.Password, req.FullName, req.Phone, _web.BaseUrl);

        if (!ok) return BadRequest(new AuthResponse { Success = false, Message = message });

        return Ok(new AuthResponse
        {
            Success = true,
            Message = message,
            RequiresEmailConfirmation = requiresConfirmation,
            AccessToken = token?.AccessToken,
            RefreshToken = token?.RefreshToken,
            Profile = token is null ? null : new FarmerProfile { Id = token.UserId, Email = token.Email, FullName = req.FullName, Phone = req.Phone, Role = "buyer" }
        });
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest req)
    {
        var (ok, message, token) = await _auth.SignInAsync(req.Email, req.Password);
        if (!ok || token is null) return Unauthorized(new AuthResponse { Success = false, Message = message });

        var profile = await LoadProfileAsync(token.AccessToken, token.UserId, token.Email);

        return Ok(new AuthResponse
        {
            Success = true,
            Message = message,
            AccessToken = token.AccessToken,
            RefreshToken = token.RefreshToken,
            Profile = profile
        });
    }

    [HttpPost("refresh")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Refresh(RefreshRequest req)
    {
        var (ok, message, token) = await _auth.RefreshAsync(req.RefreshToken);
        if (!ok || token is null) return Unauthorized(new AuthResponse { Success = false, Message = message });

        return Ok(new AuthResponse
        {
            Success = true,
            Message = message,
            AccessToken = token.AccessToken,
            RefreshToken = token.RefreshToken
        });
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout()
    {
        var token = HttpContext.Items["SupabaseAccessToken"] as string;
        if (!string.IsNullOrEmpty(token)) await _auth.SignOutAsync(token);
        return Ok(new { success = true, message = "Logged out." });
    }

    /// <summary>Change your own password. Used for first login too: the
    /// company hands the farmer a starting password, and they replace it
    /// here. Verifies the current password before changing anything.</summary>
    [HttpPut("password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword(ChangePasswordRequest req)
    {
        var token = HttpContext.Items["SupabaseAccessToken"] as string;
        var email = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
        if (token is null || email is null) return Unauthorized();

        if (string.IsNullOrWhiteSpace(req.NewPassword) || req.NewPassword.Length < 6)
            return BadRequest(new { message = "New password must be at least 6 characters." });
        if (req.NewPassword == req.CurrentPassword)
            return BadRequest(new { message = "New password must be different from the current one." });

        // Prove they know the current password (a stolen/left-open session
        // alone shouldn't be enough to lock the real owner out).
        var (verified, _, fresh) = await _auth.SignInAsync(email, req.CurrentPassword);
        if (!verified || fresh is null) return BadRequest(new { message = "Your current password is incorrect." });

        // Use the session just created by that sign-in: Supabase can require
        // a recent login for password changes, and this one is as recent as
        // it gets (the older session token may be days old).
        var (ok, message) = await _auth.UpdatePasswordAsync(fresh.AccessToken, req.NewPassword);
        if (!ok) return BadRequest(new { message });
        return Ok(new { success = true, message });
    }

    /// <summary>"Forgot password": Supabase emails a reset link. The answer is the
    /// same whether or not the address has an account, so this can't be used to
    /// find out who is registered.</summary>
    [HttpPost("forgot-password")]
    [AllowAnonymous]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Email))
            return BadRequest(new { message = "Enter your email address." });

        var (ok, message) = await _auth.SendRecoveryAsync(req.Email.Trim(), _web.BaseUrl);
        if (!ok) return BadRequest(new { message });
        return Ok(new { success = true, message = "If that email has an account, a reset link is on its way." });
    }

    /// <summary>Sets a new password using the short-lived token from the reset
    /// email's link (sent as the Bearer token). No current password needed,
    /// because the person proved they own the inbox.</summary>
    [HttpPost("reset-password")]
    [Authorize]
    public async Task<IActionResult> ResetPassword(ResetPasswordRequest req)
    {
        var token = HttpContext.Items["SupabaseAccessToken"] as string;
        if (token is null) return Unauthorized();

        if (string.IsNullOrWhiteSpace(req.NewPassword) || req.NewPassword.Length < 6)
            return BadRequest(new { message = "New password must be at least 6 characters." });

        var (ok, message) = await _auth.UpdatePasswordAsync(token, req.NewPassword);
        if (!ok) return BadRequest(new { message });
        return Ok(new { success = true, message = "Password updated. You can log in with it now." });
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<ActionResult<FarmerProfile>> Me()
    {
        var token = HttpContext.Items["SupabaseAccessToken"] as string;
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var email = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
        if (token is null || userId is null) return Unauthorized();

        var profile = await LoadProfileAsync(token, userId, email);
        return Ok(profile);
    }

    [HttpPut("me")]
    [Authorize]
    public async Task<ActionResult<FarmerProfile>> UpdateMe(UpdateProfileRequest req)
    {
        var token = HttpContext.Items["SupabaseAccessToken"] as string;
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var email = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
        if (token is null || userId is null) return Unauthorized();

        var (ok, error) = await _rest.UpdateProfileAsync(token, userId, req);
        if (!ok) return BadRequest(new { error });

        var profile = await LoadProfileAsync(token, userId, email);
        return Ok(profile);
    }

    private async Task<FarmerProfile> LoadProfileAsync(string accessToken, string userId, string? email)
    {
        // profiles.id/email/full_name/phone are populated by the
        // handle_new_user() trigger (see 001_init.sql) right after signup,
        // so this row should already exist by the time login succeeds.
        var profile = await _rest.GetProfileAsync(accessToken, userId);
        return profile ?? new FarmerProfile { Id = userId, Email = email };
    }
}
