#!/usr/bin/env bash
# Starts the API (5050) and the website (5080) together. Ctrl+C stops both.
cd "$(dirname "$0")"
dotnet run --project backend-aspnet/AgricastLivestock.Api &
API=$!
trap 'kill $API 2>/dev/null' EXIT
dotnet run --project web-aspnet/AgricastLivestock.Web
