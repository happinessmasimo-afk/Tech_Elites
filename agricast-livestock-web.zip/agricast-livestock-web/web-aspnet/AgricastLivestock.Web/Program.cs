using System.Text.Json;

// Agricast Livestock - web front end.
//
// This project only *serves* the website (everything in wwwroot/). All data
// still comes from the existing AgricastLivestock.Api backend, which in turn
// talks to Supabase - exactly like the Flutter app does. The browser calls
// that API directly (CORS is already open on it).
var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Settings the browser needs (API address + public Mapbox token) come from
// appsettings.json, so you change them in one place and never edit JS.
app.MapGet("/app-config.js", (IConfiguration config) =>
{
    var settings = new
    {
        apiBaseUrl = config["Api:BaseUrl"] ?? "http://localhost:5050",
        mapboxToken = config["Mapbox:Token"] ?? ""
    };
    var script = "window.APP_CONFIG = " + JsonSerializer.Serialize(settings) + ";";
    return Results.Text(script, "application/javascript");
});

app.UseDefaultFiles();
app.UseStaticFiles();

// Hash-based routing means every page is index.html, but this keeps any
// unknown path (e.g. a refresh on a bookmarked URL) landing on the app too.
app.MapFallbackToFile("index.html");

app.Run();
