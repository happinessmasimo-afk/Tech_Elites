// Tiny hash router: '#/listing/abc' -> loader({ params, query }).
import { auth, homePath } from './auth.js';
import { h, loading, errorBox, closeAllModals } from './ui.js';

const routes = [];
let leave = null;
let token = 0;
const listeners = new Set();

export function route(pattern, loader, opts = {}) {
  const keys = [];
  const rx = new RegExp('^' + pattern.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ rx, keys, loader, opts });
}

export const onNavigate = (fn) => listeners.add(fn);
export function currentPath() { return parseHash().path; }

function parseHash() {
  const raw = location.hash.replace(/^#/, '') || '/';
  const [path, qs = ''] = raw.split('?');
  return { path: path || '/', query: Object.fromEntries(new URLSearchParams(qs)) };
}

export function go(path) {
  if (location.hash === '#' + path) render(); else location.hash = '#' + path;
}
export function replace(path) {
  history.replaceState(null, '', '#' + path);
  render();
}

export async function render() {
  const myToken = ++token;
  const view = document.getElementById('view');
  const { path, query } = parseHash();

  closeAllModals();
  if (leave) { try { leave(); } catch { /* ignore */ } leave = null; }

  const match = routes.map((r) => ({ r, m: r.rx.exec(path) })).find((x) => x.m);
  if (!match) {
    view.replaceChildren(h('div', { class: 'page narrow center' }, h('h1', null, 'Page not found'), h('p', { class: 'muted' }, 'That address does not exist.'), h('p', null, h('a', { class: 'btn btn-primary', href: '#/' }, 'Go home'))));
    document.title = 'Not found - Agricast Livestock';
    listeners.forEach((fn) => fn(path));
    return;
  }

  const { opts } = match.r;
  if (opts.auth && !auth.loggedIn) { replace('/login?next=' + encodeURIComponent(path)); return; }
  if (opts.guestOnly && auth.loggedIn) { replace(homePath()); return; }
  if (opts.role === 'farmer' && !auth.isFarmer) { replace(homePath()); return; }
  if (opts.role === 'buyer' && auth.isFarmer) { replace(homePath()); return; }

  const params = {};
  match.r.keys.forEach((k, i) => { params[k] = decodeURIComponent(match.m[i + 1]); });

  view.replaceChildren(loading());
  listeners.forEach((fn) => fn(path));
  try {
    const result = await match.r.loader({ params, query });
    if (myToken !== token) { if (result && result.leave) result.leave(); return; }
    if (!result) return;
    const node = result instanceof Node ? result : result.node;
    view.replaceChildren(node);
    document.title = (result.title ? result.title + ' - ' : '') + 'Agricast Livestock';
    leave = result.leave || null;
    window.scrollTo(0, 0);
    if (result.mounted) result.mounted();
  } catch (e) {
    if (myToken !== token) return;
    view.replaceChildren(h('div', { class: 'page' }, errorBox(e.message || 'Something went wrong.', () => render())));
  }
}

export function startRouter() {
  window.addEventListener('hashchange', render);
  return render();
}
