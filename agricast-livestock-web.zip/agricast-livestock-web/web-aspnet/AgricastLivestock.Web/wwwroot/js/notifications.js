// Global notifier: runs on every page while someone is logged in.
//  - Farmer: a buyer chose delivery -> "New delivery to make" popup (+ browser notification if the tab is hidden).
//  - Buyer:  the farmer started the trip (delivery) -> toast with a link to the live map.
//  - Farmer: the buyer set off to collect (pickup) -> toast.
import { h, toast, openModal } from './ui.js';
import { deliveriesApi } from './api.js';
import { auth, onAuthChange } from './auth.js';
import { go, currentPath } from './router.js';
import { addressText } from './maps.js';

let timer = null; let seen = null; let alertOpen = false;
const statusOf = new Map();
const listeners = new Set();
export const onDeliveriesChange = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export let latestDeliveries = [];

function system(title, body) {
  try {
    if ('Notification' in window && Notification.permission === 'granted' && document.hidden) new Notification(title, { body, icon: '/img/icon.png' });
  } catch { /* notifications are a bonus */ }
}

function newDeliveryAlert(d) {
  alertOpen = true;
  openModal((close) => [
    h('h2', null, 'New delivery to make'),
    h('p', null, `${d.buyerName || 'A buyer'} bought "${d.listingTitle || 'your livestock'}" and wants it delivered to:`),
    d.destLat !== null ? h('div', { style: { fontWeight: '700' } }, addressText(d.destLat, d.destLng)) : null,
    h('div', { class: 'modal-actions' }, h('button', { class: 'btn btn-outline', type: 'button', onclick: () => close(false) }, 'Later'),
      h('button', { class: 'btn btn-primary', type: 'button', onclick: () => close(true) }, 'See route and start')),
  ], { onClose: (yes) => { alertOpen = false; if (yes === true) go(`/trip/${encodeURIComponent(d.id)}`); } });
}

async function check() {
  if (!auth.loggedIn) return;
  let list;
  try { list = await deliveriesApi.active(); } catch { return; }
  latestDeliveries = list;
  const first = seen === null;
  if (first) seen = new Set();
  for (const d of list) {
    const wasKnown = seen.has(d.id); const before = statusOf.get(d.id);
    seen.add(d.id); statusOf.set(d.id, d.status);
    if (first) continue;
    const onTrip = currentPath() === `/trip/${d.id}`;
    const isDelivery = d.method === 'delivery';
    if (auth.isFarmer && isDelivery && !wasKnown && d.status === 'pending' && !alertOpen) {
      newDeliveryAlert(d); system('New delivery to make', `${d.listingTitle || 'Livestock'} for ${d.buyerName || 'a buyer'}`);
    }
    if (wasKnown && before === 'pending' && d.status === 'in_transit' && !onTrip && d.travelerId !== auth.userId) {
      const msg = isDelivery ? `The farmer has started delivering "${d.listingTitle || 'your order'}". Follow them live.` : `${d.buyerName || 'The buyer'} is on the way to collect "${d.listingTitle || 'the order'}".`;
      toast(msg, 'ok'); system(isDelivery ? 'Your delivery is on the way' : 'Buyer is on the way', msg);
    }
  }
  listeners.forEach((fn) => fn(list));
}

export function startNotifier() {
  onAuthChange(() => {
    if (auth.loggedIn && !timer) { seen = null; statusOf.clear(); check(); timer = setInterval(check, 10000); }
    else if (!auth.loggedIn && timer) { clearInterval(timer); timer = null; seen = null; latestDeliveries = []; }
  });
}

// Small bar offering browser notifications (shown once, only when still undecided).
export function notificationPrompt() {
  if (!('Notification' in window) || Notification.permission !== 'default') return null;
  const bar = h('div', { class: 'notify-bar' }, h('span', null, 'Get a browser alert when a delivery starts or a new one needs you.'),
    h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: async () => { try { await Notification.requestPermission(); } catch { /* ignore */ } bar.remove(); } }, 'Turn on'),
    h('button', { class: 'btn btn-sm', type: 'button', onclick: () => bar.remove() }, 'Not now'));
  return bar;
}
