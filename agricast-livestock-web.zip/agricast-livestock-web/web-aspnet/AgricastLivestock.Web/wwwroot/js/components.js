import { h, icon, money, priceParts, pill, capitalize } from './ui.js';

export function priceTag(listing, big = false) {
  const { amount, unit } = priceParts(listing);
  return h('span', { class: big ? 'tag big' : 'tag' }, amount, h('small', null, unit));
}

export function listingCard(l, { showStatus = false } = {}) {
  const photo = l.photoUrls[0];
  const meta = [l.species, l.breed, l.sex ? capitalize(l.sex) : null].filter(Boolean).join(', ');
  return h('a', { class: 'lcard', href: `#/listing/${encodeURIComponent(l.id)}` },
    h('div', { class: 'lcard-img' },
      photo ? h('img', { src: photo, alt: '', loading: 'lazy' }) : h('div', { class: 'ph' }, icon('paw', 44)),
      priceTag(l)),
    h('div', { class: 'lcard-body' },
      h('h3', null, l.title),
      h('div', { class: 'lcard-meta' }, meta),
      h('div', { class: 'lcard-foot' },
        h('span', { class: 'loc' }, l.location ? [icon('pin', 15), h('span', null, l.location)] : null),
        h('span', null, showStatus ? pill(l.status) : `${l.quantity} available`))));
}

export { money };
