// Talks to the ASP.NET backend only (never to Supabase directly) - same
// contract the Flutter app uses. Attaches the stored access token, and on a
// 401 silently refreshes it once and retries.

const CFG = window.APP_CONFIG || {};
export const API_BASE = (CFG.apiBaseUrl || 'http://localhost:5050').replace(/\/$/, '');
export const MAPBOX_TOKEN = CFG.mapboxToken || '';

const ACCESS = 'agricast.access';
const REFRESH = 'agricast.refresh';

function store(key, value) {
  try {
    if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, value);
  } catch { /* storage blocked: session just won't persist across reloads */ }
}
function read(key) { try { return localStorage.getItem(key); } catch { return null; } }

let memAccess = read(ACCESS);
let memRefresh = read(REFRESH);

export const session = {
  get access() { return memAccess; },
  get refresh() { return memRefresh; },
  save(access, refresh) { memAccess = access; memRefresh = refresh; store(ACCESS, access); store(REFRESH, refresh); },
  clear() { memAccess = null; memRefresh = null; store(ACCESS, null); store(REFRESH, null); },
};

export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

let refreshing = null;
async function tryRefresh() {
  if (!session.refresh) return false;
  if (!refreshing) {
    refreshing = (async () => {
      try {
        const res = await fetch(API_BASE + '/api/auth/refresh', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken: session.refresh }),
        });
        if (!res.ok) { session.clear(); window.dispatchEvent(new Event('agricast:session-expired')); return false; }
        const data = await res.json();
        if (!data.accessToken || !data.refreshToken) return false;
        session.save(data.accessToken, data.refreshToken);
        return true;
      } catch { return false; }
      finally { refreshing = null; }
    })();
  }
  return refreshing;
}

async function request(method, path, body, { auth = true, form = null, token = null } = {}) {
  const send = () => {
    const headers = {};
    // `token` overrides the saved session (used by the password-reset link's short-lived token).
    if (token) headers.Authorization = 'Bearer ' + token;
    else if (auth && session.access) headers.Authorization = 'Bearer ' + session.access;
    let payload;
    if (form) payload = form;
    else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
    return fetch(API_BASE + path, { method, headers, body: payload });
  };

  let res;
  try { res = await send(); }
  catch {
    throw new ApiError(`Can't reach the Agricast API at ${API_BASE}. Make sure the backend is running.`, 0);
  }

  if (res.status === 401 && auth && !token && session.refresh) {
    if (await tryRefresh()) {
      try { res = await send(); } catch { throw new ApiError(`Can't reach the Agricast API at ${API_BASE}.`, 0); }
    }
  }

  const text = await res.text();
  let data = null;
  if (text) { try { data = JSON.parse(text); } catch { data = null; } }

  if (res.ok) return data;

  let message = `Request failed (${res.status}).`;
  if (data && typeof data === 'object') {
    if (data.message) message = data.message;
    if (data.error) message = typeof data.error === 'string' ? data.error : JSON.stringify(data.error);
  }
  if (res.status === 401 && message.startsWith('Request failed')) message = 'Your session has expired. Please log in again.';
  throw new ApiError(message, res.status);
}

export const http = {
  get: (p, o) => request('GET', p, undefined, o),
  post: (p, b, o) => request('POST', p, b ?? {}, o),
  put: (p, b, o) => request('PUT', p, b ?? {}, o),
  patch: (p, b, o) => request('PATCH', p, b ?? {}, o),
  del: (p, o) => request('DELETE', p, undefined, o),
  upload: (p, form) => request('POST', p, undefined, { form }),
};

// ---- model normalisers (the API mixes snake_case and camelCase) ----------
const pick = (j, ...keys) => { for (const k of keys) if (j[k] !== undefined && j[k] !== null) return j[k]; return null; };
const num = (v) => { if (v === null || v === undefined || v === '') return null; const n = Number(v); return Number.isFinite(n) ? n : null; };
const date = (v) => { if (!v) return null; const d = new Date(v); return isNaN(d) ? null : d; };

export function toProfile(j) {
  if (!j) return null;
  return { id: j.id ?? j.Id ?? '', email: j.email ?? j.Email ?? null, fullName: j.fullName ?? j.FullName ?? null, phone: j.phone ?? j.Phone ?? null, location: j.location ?? j.Location ?? null, role: j.role ?? j.Role ?? 'buyer' };
}

export function toListing(j) {
  return {
    id: String(j.id ?? ''), ownerId: String(pick(j, 'owner_id', 'ownerId') ?? ''),
    title: j.title ?? '', species: j.species ?? '', breed: j.breed ?? null, sex: j.sex ?? null,
    quantity: num(j.quantity) ?? 1, ageMonths: num(pick(j, 'age_months', 'ageMonths')), weightKg: num(pick(j, 'weight_kg', 'weightKg')),
    askingPrice: num(pick(j, 'asking_price', 'askingPrice')) ?? 0, priceUnit: pick(j, 'price_unit', 'priceUnit') ?? 'per_head',
    status: j.status ?? 'active', description: j.description ?? null, location: j.location ?? null,
    photoUrls: (pick(j, 'photo_urls', 'photoUrls') || []).map(String),
    latitude: num(j.latitude), longitude: num(j.longitude),
    soldPrice: num(pick(j, 'sold_price', 'soldPrice')), soldAt: date(pick(j, 'sold_at', 'soldAt')), createdAt: date(pick(j, 'created_at', 'createdAt')),
  };
}

export function toOffer(j) {
  const l = j.listings || j.listing || null;
  return {
    id: String(j.id ?? ''), listingId: String(pick(j, 'listing_id', 'listingId') ?? ''), buyerId: pick(j, 'buyer_id', 'buyerId'),
    buyerName: pick(j, 'buyer_name', 'buyerName'), buyerPhone: pick(j, 'buyer_phone', 'buyerPhone'),
    offerPrice: num(pick(j, 'offer_price', 'offerPrice')), message: j.message ?? null, status: j.status ?? 'pending',
    createdAt: date(pick(j, 'created_at', 'createdAt')), listingTitle: l ? l.title ?? null : null,
    listingAskingPrice: l ? num(pick(l, 'asking_price', 'askingPrice')) : null,
    paymentStatus: pick(j, 'payment_status', 'paymentStatus') ?? 'unpaid', declineReason: pick(j, 'decline_reason', 'declineReason'),
    get amount() { return this.offerPrice ?? this.listingAskingPrice ?? 0; },
  };
}

export function toDelivery(j) {
  const l = j.listings && typeof j.listings === 'object' ? j.listings : null;
  const o = j.listing_offers && typeof j.listing_offers === 'object' ? j.listing_offers : null;
  const d = {
    id: String(j.id ?? ''), offerId: String(pick(j, 'offer_id', 'offerId') ?? ''), listingId: String(pick(j, 'listing_id', 'listingId') ?? ''),
    farmerId: String(pick(j, 'farmer_id', 'farmerId') ?? ''), buyerId: String(pick(j, 'buyer_id', 'buyerId') ?? ''),
    method: j.method ?? 'pickup', status: j.status ?? 'pending',
    buyerLatitude: num(j.buyer_latitude), buyerLongitude: num(j.buyer_longitude), farmerLatitude: num(j.farmer_latitude), farmerLongitude: num(j.farmer_longitude),
    distanceKm: num(j.distance_km), etaMinutes: num(j.eta_minutes), startedAt: date(pick(j, 'started_at', 'startedAt')),
    listingTitle: l ? l.title ?? null : null, buyerName: o ? o.buyer_name ?? null : null, buyerPhone: o ? o.buyer_phone ?? null : null,
  };
  const pickup = d.method === 'pickup';
  d.travelerId = pickup ? d.buyerId : d.farmerId;          // pickup: the buyer travels; delivery: the farmer travels
  d.travelerLat = pickup ? d.buyerLatitude : d.farmerLatitude;
  d.travelerLng = pickup ? d.buyerLongitude : d.farmerLongitude;
  d.destLat = pickup ? d.farmerLatitude : d.buyerLatitude;   // the fixed point being travelled to
  d.destLng = pickup ? d.farmerLongitude : d.buyerLongitude;
  return d;
}

// Update/start/location responses don't embed listing + buyer details, so
// carry those over from the previous copy instead of losing them.
export function mergeDelivery(next, old) {
  if (!old) return next;
  return { ...next, listingTitle: next.listingTitle ?? old.listingTitle, buyerName: next.buyerName ?? old.buyerName, buyerPhone: next.buyerPhone ?? old.buyerPhone };
}

// ---- endpoints -----------------------------------------------------------
export const listingsApi = {
  active: async () => (await http.get('/api/listings')).map(toListing),
  mine: async () => (await http.get('/api/listings/mine')).map(toListing),
  get: async (id) => toListing(await http.get(`/api/listings/${encodeURIComponent(id)}`)),
  create: async (body) => toListing(await http.post('/api/listings', body)),
  setStatus: async (id, status) => toListing(await http.put(`/api/listings/${encodeURIComponent(id)}`, { status })),
  markSold: async (id, soldPrice) => toListing(await http.put(`/api/listings/${encodeURIComponent(id)}`, { status: 'sold', soldPrice })),
};

export const offersApi = {
  mine: async () => (await http.get('/api/offers/mine')).map(toOffer),
  make: async (listingId, body) => toOffer(await http.post(`/api/listings/${encodeURIComponent(listingId)}/offers`, body)),
  buyNow: async (listingId, body) => toOffer(await http.post(`/api/listings/${encodeURIComponent(listingId)}/buy-now`, body)),
  update: async (id, status, reason) => toOffer(await http.patch(`/api/offers/${encodeURIComponent(id)}`, reason ? { status, reason } : { status })),
};

export const paymentsApi = {
  pay: async (offerId, cardHolderName, cardNumberLast4) => {
    const data = await http.post('/api/payments/dummy-pay', { offerId, cardHolderName, cardNumberLast4 });
    return data && data.offer ? toOffer(data.offer) : null;
  },
};

export const deliveriesApi = {
  active: async () => (await http.get('/api/deliveries')).map(toDelivery),
  byOffer: async (offerId) => toDelivery(await http.get(`/api/deliveries/by-offer/${encodeURIComponent(offerId)}`)),
  get: async (id) => toDelivery(await http.get(`/api/deliveries/${encodeURIComponent(id)}`)),
  create: async (body) => toDelivery(await http.post('/api/deliveries', body)),
  start: async (id) => toDelivery(await http.post(`/api/deliveries/${encodeURIComponent(id)}/start`, {})),
  location: async (id, latitude, longitude) => toDelivery(await http.patch(`/api/deliveries/${encodeURIComponent(id)}/location`, { latitude, longitude })),
  status: async (id, status) => toDelivery(await http.patch(`/api/deliveries/${encodeURIComponent(id)}/status`, { status })),
};

export const financeApi = {
  summary: async () => {
    const j = await http.get('/api/finance/summary');
    return { totalRevenue: num(pick(j, 'totalRevenue', 'total_revenue')) ?? 0, soldCount: num(pick(j, 'soldCount', 'sold_count')) ?? 0, soldListings: (pick(j, 'soldListings', 'sold_listings') || []).map(toListing) };
  },
};

export const uploadsApi = {
  listingPhoto: async (file) => {
    const form = new FormData();
    form.append('file', file, file.name);
    const data = await http.upload('/api/uploads/listing-photo', form);
    return data.url;
  },
};

export const receiptsApi = {
  get: (offerId) => http.get(`/api/receipts/${encodeURIComponent(offerId)}`).then(toReceipt),
  email: (offerId) => http.post(`/api/receipts/${encodeURIComponent(offerId)}/email`, {}),
};

export function toReceipt(j) {
  return {
    slipNumber: j.slipNumber, offerId: j.offerId, issuedAt: date(j.issuedAt), viewerRole: j.viewerRole,
    buyerName: j.buyerName, buyerPhone: j.buyerPhone ?? null, buyerEmail: j.buyerEmail ?? null, sellerName: j.sellerName ?? null,
    itemTitle: j.itemTitle, species: j.species, breed: j.breed ?? null, sex: j.sex ?? null, quantity: num(j.quantity) ?? 1,
    itemLocation: j.itemLocation ?? null, priceUnit: j.priceUnit ?? 'per_head', unitPrice: num(j.unitPrice) ?? 0, amountPaid: num(j.amountPaid) ?? 0,
    method: j.fulfilmentMethod ?? null, status: j.fulfilmentStatus ?? null, lat: num(j.fulfilmentLatitude), lng: num(j.fulfilmentLongitude),
  };
}
