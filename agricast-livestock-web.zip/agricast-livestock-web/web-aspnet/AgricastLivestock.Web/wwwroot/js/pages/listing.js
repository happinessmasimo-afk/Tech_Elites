import { h, icon, field, openModal, toast, withBusy, backLink, pill, capitalize, money } from '../ui.js';
import { listingsApi, offersApi } from '../api.js';
import { auth } from '../auth.js';
import { go } from '../router.js';
import { priceTag } from '../components.js';
import { mountMap } from '../maps.js';

function offerDialog(listing) {
  openModal((close) => {
    const name = h('input', { class: 'input', value: auth.profile?.fullName || '', autocomplete: 'name' });
    const phone = h('input', { class: 'input', type: 'tel', value: auth.profile?.phone || '', autocomplete: 'tel' });
    const price = h('input', { class: 'input', type: 'number', min: '0', step: 'any', inputmode: 'decimal', placeholder: `Asking price is ${money(listing.askingPrice)}` });
    const message = h('textarea', { class: 'textarea', placeholder: 'e.g. Can you do a better price on 3 animals?' });
    const err = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
    const send = h('button', { class: 'btn btn-primary', type: 'button' }, 'Send offer');
    send.onclick = () => withBusy(send, async () => {
      err.hidden = true;
      if (!name.value.trim() || !phone.value.trim()) { err.textContent = 'Enter your name and phone so the farmer can reach you.'; err.hidden = false; return; }
      const amount = price.value.trim() === '' ? null : parseFloat(price.value);
      if (amount !== null && (!Number.isFinite(amount) || amount <= 0)) { err.textContent = 'Enter a valid offer price, or leave it blank.'; err.hidden = false; return; }
      try {
        await offersApi.make(listing.id, { buyerName: name.value.trim(), buyerPhone: phone.value.trim(), offerPrice: amount, message: message.value.trim() || null });
        close();
        toast('Offer sent!', 'ok');
        go('/my-offers');
      } catch (e) { err.textContent = `Could not send offer. ${e.message}`; err.hidden = false; }
    });
    return [
      h('h2', null, `Make an offer on "${listing.title}"`),
      h('p', { class: 'muted small' }, 'Negotiate a different price. The farmer can accept or decline, and you can withdraw any time.'),
      field('Your name', name), field('Your phone', phone), field('Offer price in rand (optional)', price), field('Message (optional)', message), err,
      h('div', { class: 'modal-actions' }, h('button', { class: 'btn btn-outline', type: 'button', onclick: () => close() }, 'Cancel'), send),
    ];
  });
}

function buyNowDialog(listing) {
  openModal((close) => {
    const name = h('input', { class: 'input', value: auth.profile?.fullName || '', autocomplete: 'name' });
    const phone = h('input', { class: 'input', type: 'tel', value: auth.profile?.phone || '', autocomplete: 'tel' });
    const err = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
    const go_ = h('button', { class: 'btn btn-primary', type: 'button' }, 'Continue to payment');
    go_.onclick = () => withBusy(go_, async () => {
      err.hidden = true;
      if (!name.value.trim() || !phone.value.trim()) { err.textContent = 'Enter your name and phone.'; err.hidden = false; return; }
      try {
        const offer = await offersApi.buyNow(listing.id, { buyerName: name.value.trim(), buyerPhone: phone.value.trim() });
        close();
        go(`/checkout/${encodeURIComponent(offer.id)}`);
      } catch (e) { err.textContent = `Could not start the purchase. ${e.message}`; err.hidden = false; }
    });
    return [
      h('h2', null, `Buy "${listing.title}" now`),
      h('p', { class: 'muted small' }, `Skips negotiation and buys immediately at the listed price of ${money(listing.askingPrice)}${listing.priceUnit === 'per_kg' ? '/kg' : '/head'}.`),
      field('Your name', name), field('Your phone', phone), err,
      h('div', { class: 'modal-actions' }, h('button', { class: 'btn btn-outline', type: 'button', onclick: () => close() }, 'Cancel'), go_),
    ];
  });
}

export async function listingPage({ params }) {
  const l = await listingsApi.get(params.id);
  const isOwner = auth.loggedIn && auth.userId === l.ownerId;
  const canTransact = !isOwner && l.status === 'active';
  const nextHere = encodeURIComponent(`/listing/${l.id}`);

  // gallery
  const main = h('div', { class: 'gallery-main' });
  const thumbs = h('div', { class: 'thumbs' });
  const show = (i) => {
    main.replaceChildren(l.photoUrls.length ? h('img', { src: l.photoUrls[i], alt: `${l.title}, photo ${i + 1} of ${l.photoUrls.length}` }) : icon('paw', 72));
    [...thumbs.children].forEach((b, idx) => b.setAttribute('aria-current', String(idx === i)));
  };
  if (l.photoUrls.length > 1) l.photoUrls.forEach((u, i) => thumbs.append(h('button', { type: 'button', 'aria-label': `Show photo ${i + 1}`, onclick: () => show(i) }, h('img', { src: u, alt: '' }))));
  show(0);

  const kg = l.weightKg !== null ? `${l.weightKg % 1 === 0 ? l.weightKg : l.weightKg.toFixed(1)} kg` : null;
  const specs = [['Species', l.species], l.breed && ['Breed', l.breed], l.sex && ['Sex', capitalize(l.sex)], ['Quantity', String(l.quantity)],
    l.ageMonths !== null && ['Age', `${l.ageMonths} months`], kg && ['Weight', kg], l.location && ['Location', l.location]].filter(Boolean);

  const mapBox = h('div', { class: 'map-box' });
  const hasPoint = l.latitude !== null && l.longitude !== null;

  const actions = [];
  if (canTransact) {
    actions.push(
      h('button', { class: 'btn btn-primary btn-block', type: 'button', onclick: () => (auth.loggedIn ? buyNowDialog(l) : go(`/login?next=${nextHere}`)) },
        auth.loggedIn ? `Buy now at ${money(l.askingPrice)}` : 'Log in to buy'),
      h('button', { class: 'btn btn-outline btn-block', type: 'button', onclick: () => (auth.loggedIn ? offerDialog(l) : go(`/login?next=${nextHere}`)) },
        auth.loggedIn ? 'Make an offer instead' : 'Log in to make an offer'));
  } else if (isOwner) {
    actions.push(h('p', { class: 'muted' }, 'This is your listing.'), h('a', { class: 'btn btn-outline btn-block', href: '#/my-listings' }, 'Manage my listings'));
  } else {
    actions.push(h('p', { class: 'muted' }, 'This listing is no longer available.'));
  }

  const node = h('div', { class: 'page' },
    backLink('#/marketplace', 'Marketplace'),
    h('div', { class: 'detail' },
      h('div', { class: 'stack' }, main, thumbs,
        l.description ? h('div', { class: 'stack-sm' }, h('h2', null, 'Description'), h('p', { style: { whiteSpace: 'pre-wrap' } }, l.description)) : null),
      h('div', { class: 'buybox' },
        h('div', { class: 'row between', style: { alignItems: 'flex-start' } }, h('h1', { style: { fontSize: '26px' } }, l.title), pill(l.status)),
        h('div', null, priceTag(l, true)),
        h('div', { class: 'specs' }, h('dl', null, ...specs.map(([k, v]) => h('div', { class: 'spec' }, h('dt', null, k), h('dd', null, v))))),
        ...actions,
        hasPoint ? h('div', { class: 'stack-sm' }, h('h3', null, 'Where it is'), mapBox) : null)));

  return {
    title: l.title, node,
    mounted: () => { if (hasPoint) mountMap(mapBox, { center: [l.latitude, l.longitude], zoom: 13, markers: [{ lat: l.latitude, lng: l.longitude, kind: 'pin', label: l.title }] }); },
  };
}
