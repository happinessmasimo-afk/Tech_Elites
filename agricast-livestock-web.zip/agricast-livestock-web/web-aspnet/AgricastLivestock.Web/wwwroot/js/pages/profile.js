import { h, field, backLink, toast, withBusy, pill, icon } from '../ui.js';
import { auth, logout, updateProfile, changePassword } from '../auth.js';
import { go } from '../router.js';

export async function profilePage() {
  const p = auth.profile;
  const initials = (p?.fullName || p?.email || '?').trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  const row = (ic, label, value) => h('div', null, h('span', { class: 'muted' }, icon(ic, 20)), h('div', null, h('div', { class: 'k' }, label), h('div', { class: 'v' }, value || 'Not set')));

  const logoutBtn = h('button', { class: 'btn btn-danger btn-block', type: 'button' }, 'Log out');
  logoutBtn.onclick = () => withBusy(logoutBtn, async () => { await logout(); go('/'); });

  return { title: 'Profile', node: h('div', { class: 'page narrow' }, h('div', { class: 'stack' },
    h('div', { class: 'row', style: { gap: '16px' } }, h('div', { class: 'avatar' }, initials),
      h('div', { class: 'grow' }, h('h1', { style: { fontSize: '24px' } }, p?.fullName || 'Your account'), h('div', { style: { marginTop: '6px' } }, pill(auth.isFarmer ? 'active' : 'pending', auth.isFarmer ? 'Farmer' : 'Buyer')))),
    h('div', { class: 'card info-rows' }, row('mail', 'Email', p?.email), row('user', 'Phone', p?.phone), row('pin', 'Location', p?.location)),
    h('a', { class: 'btn btn-outline btn-block', href: '#/profile/edit' }, 'Edit profile'),
    h('a', { class: 'btn btn-outline btn-block', href: '#/profile/password' }, icon('lock', 18), 'Change password'),
    logoutBtn)) };
}

export async function editProfilePage() {
  const p = auth.profile || {};
  const name = h('input', { class: 'input', value: p.fullName || '', autocomplete: 'name' });
  const phone = h('input', { class: 'input', type: 'tel', value: p.phone || '', autocomplete: 'tel' });
  const location = h('input', { class: 'input', value: p.location || '', placeholder: 'Town or area' });
  const err = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save changes');
  const form = h('form', { class: 'stack', onsubmit: async (e) => {
    e.preventDefault(); err.hidden = true;
    await withBusy(save, async () => {
      try { await updateProfile({ fullName: name.value.trim(), phone: phone.value.trim(), location: location.value.trim() }); toast('Profile updated.', 'ok'); go('/profile'); }
      catch (e2) { err.textContent = e2.message; err.hidden = false; }
    });
  } }, field('Full name', name), field('Phone', phone), field('Location', location), err, h('div', { class: 'row' }, save, h('a', { class: 'btn btn-outline', href: '#/profile' }, 'Cancel')));
  return { title: 'Edit profile', node: h('div', { class: 'page narrow' }, backLink('#/profile', 'Profile'), h('div', { class: 'page-head' }, h('h1', null, 'Edit profile')), form) };
}

export async function changePasswordPage() {
  const cur = h('input', { class: 'input', type: 'password', autocomplete: 'current-password' });
  const next = h('input', { class: 'input', type: 'password', autocomplete: 'new-password' });
  const confirm = h('input', { class: 'input', type: 'password', autocomplete: 'new-password' });
  const err = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
  const save = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Change password');
  const fail = (m) => { err.textContent = m; err.hidden = false; };
  const form = h('form', { class: 'stack', onsubmit: async (e) => {
    e.preventDefault(); err.hidden = true;
    if (!cur.value) return fail('Enter your current password.');
    if (next.value.length < 6) return fail('The new password must be at least 6 characters.');
    if (next.value !== confirm.value) return fail('The new passwords do not match.');
    await withBusy(save, async () => {
      try { await changePassword(cur.value, next.value); toast('Password changed.', 'ok'); go('/profile'); }
      catch (e2) { fail(e2.message); }
    });
  } }, field('Current password', cur), field('New password (min 6 characters)', next), field('Confirm new password', confirm), err, h('div', { class: 'row' }, save, h('a', { class: 'btn btn-outline', href: '#/profile' }, 'Cancel')));
  return { title: 'Change password', node: h('div', { class: 'page narrow' }, backLink('#/profile', 'Profile'), h('div', { class: 'page-head' }, h('h1', null, 'Change password')), form) };
}
