import { h, empty, errorBox, loading, money, formatDate } from '../ui.js';
import { financeApi } from '../api.js';

export async function financePage() {
  const body = h('div');
  async function load() {
    body.replaceChildren(loading());
    try {
      const f = await financeApi.summary();
      body.replaceChildren(h('div', { class: 'stack' },
        h('div', { class: 'totalcard' }, h('div', { class: 'l' }, 'Total revenue'), h('div', { class: 'n' }, money(f.totalRevenue)), h('div', { class: 'l' }, `${f.soldCount} listing${f.soldCount === 1 ? '' : 's'} sold`)),
        h('h2', null, 'Sold listings'),
        f.soldListings.length ? h('div', { class: 'card-list' }, ...f.soldListings.map((l) => h('a', { class: 'card line-item', href: `#/listing/${encodeURIComponent(l.id)}`, style: { textDecoration: 'none', color: 'inherit' } },
          l.photoUrls[0] ? h('img', { class: 'thumb', src: l.photoUrls[0], alt: '' }) : h('div', { class: 'thumb' }),
          h('div', { class: 'grow' }, h('div', { style: { fontWeight: '700' } }, l.title), h('div', { class: 'muted small' }, l.soldAt ? `Sold ${formatDate(l.soldAt)}` : 'Sold')),
          h('div', { class: 'amt' }, money(l.soldPrice ?? l.askingPrice)))))
          : empty('Nothing marked as sold yet', 'When a buyer pays for an order, or you mark a listing as sold, it is counted here.')));
    } catch (e) { body.replaceChildren(errorBox(`Could not load finance data. ${e.message}`, load)); }
  }
  load();
  return { title: 'Finance', node: h('div', { class: 'page medium' }, h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Finance'), h('p', null, 'Revenue from everything you have sold.'))), body) };
}
