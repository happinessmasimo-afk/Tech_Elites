import { h } from '../ui.js';
import { auth, homePath } from '../auth.js';
import { replace } from '../router.js';

export async function landingPage() {
  if (auth.loggedIn) { replace(homePath()); return null; }
  return {
    title: 'Buy and sell livestock',
    node: h('div', { class: 'split' },
      h('div', { class: 'split-art hero', style: { backgroundImage: "url('/img/hero.jpg')" }, role: 'img', 'aria-label': 'A brown cow standing in a green mountain pasture' }),
      h('div', { class: 'split-body' },
        h('div', { class: 'inner' },
          h('h1', null, 'Buy and sell livestock directly from the farm'),
          h('p', { class: 'muted' }, 'Browse cattle, goats, sheep and more. Make an offer or buy at the asking price, then arrange pickup or delivery and follow the trip live.'),
          h('div', { class: 'cta-stack' },
            h('a', { class: 'btn btn-primary btn-block', href: '#/login' }, 'Log in'),
            h('a', { class: 'btn btn-outline btn-block', href: '#/register' }, 'Create an account'),
            h('a', { class: 'btn btn-block', style: { color: 'var(--brand-deep)' }, href: '#/marketplace' }, 'Browse the marketplace without an account'))))),
  };
}
