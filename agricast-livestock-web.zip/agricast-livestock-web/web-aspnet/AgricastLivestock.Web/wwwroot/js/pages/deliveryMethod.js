import { h, icon, backLink, toast } from '../ui.js';
import { offersApi, deliveriesApi } from '../api.js';
import { go, replace } from '../router.js';
import { pickLocation } from '../maps.js';

export async function deliveryMethodPage({ params }) {
  const offers = await offersApi.mine();
  const offer = offers.find((o) => o.id === params.offerId);
  if (!offer) return { title: 'Delivery', node: h('div', { class: 'page narrow' }, backLink('#/my-offers', 'My offers'), h('div', { class: 'error-box' }, 'We could not find that order.')) };
  if (offer.paymentStatus !== 'paid') return { title: 'Delivery', node: h('div', { class: 'page narrow' }, backLink('#/my-offers', 'My offers'), h('div', { class: 'error-box' }, 'Pay for this order first, then choose how you will get it.'), h('a', { class: 'btn btn-primary', href: `#/checkout/${encodeURIComponent(offer.id)}` }, 'Go to checkout')) };

  // Already chose before? Jump straight to the trip instead of creating a second one.
  try { const existing = await deliveriesApi.byOffer(offer.id); replace(`/trip/${encodeURIComponent(existing.id)}`); return null; }
  catch (e) { if (e.status !== 404) throw e; }

  const err = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
  const buttons = [];
  const busy = (on) => buttons.forEach((b) => { b.disabled = on; });
  const fail = (m) => { err.textContent = m; err.hidden = false; busy(false); };

  const pickup = h('button', { class: 'choice', type: 'button', onclick: async () => {
    err.hidden = true; busy(true);
    try { const d = await deliveriesApi.create({ offerId: offer.id, method: 'pickup' }); go(`/trip/${encodeURIComponent(d.id)}`); }
    catch (e) { fail(`Could not save your choice. ${e.message}`); }
  } }, h('span', { class: 'ic' }, icon('walk', 26)), h('span', null, h('b', null, "I'll collect it myself"), h('span', { class: 'muted small' }, "Start a live trip to the farm when you're on your way. The farmer sees you coming.")));

  const deliver = h('button', { class: 'choice', type: 'button', onclick: async () => {
    err.hidden = true;
    const spot = await pickLocation({ title: 'Where should it be delivered?', confirmLabel: 'Deliver here' });
    if (!spot) return;
    busy(true);
    try { const d = await deliveriesApi.create({ offerId: offer.id, method: 'delivery', buyerLatitude: spot.lat, buyerLongitude: spot.lng }); go(`/trip/${encodeURIComponent(d.id)}`); }
    catch (e) { fail(`Could not start delivery tracking. ${e.message}`); }
  } }, h('span', { class: 'ic' }, icon('truck', 26)), h('span', null, h('b', null, 'Farmer delivers to me'), h('span', { class: 'muted small' }, "Pin your location and follow the farmer's live position on the way.")));

  buttons.push(pickup, deliver);

  return { title: 'Delivery or pickup', node: h('div', { class: 'page narrow' }, backLink('#/my-offers', 'My offers'), h('div', { class: 'stack' },
    h('h1', null, 'How will you get it?'),
    h('p', { class: 'muted' }, `For "${offer.listingTitle || 'your purchase'}". You can also arrange details with the farmer directly.`),
    pickup, deliver, err,
    h('a', { class: 'btn btn-outline btn-block', href: '#/my-offers' }, "I'll decide later"))) };
}
