import { h, empty, errorBox, loading, toast, confirmDialog, promptDialog, backLink, icon, money } from '../ui.js';
import { listingsApi } from '../api.js';
import { listingCard } from '../components.js';

export async function myListingsPage() {
  const body = h('div');

  const markSold = async (l) => {
    const value = await promptDialog({
      title: 'Mark as sold', message: `What did "${l.title}" actually sell for? This feeds your Finance total.`, label: 'Sale price', prefix: 'R',
      type: 'number', initial: String(l.askingPrice), confirmLabel: 'Confirm sold',
      validate: (v) => (Number.isFinite(parseFloat(v)) && parseFloat(v) >= 0 ? null : 'Enter the sale price.'),
    });
    if (value === null) return;
    try { await listingsApi.markSold(l.id, parseFloat(value)); toast(`${l.title} marked as sold.`, 'ok'); load(); }
    catch (e) { toast(`Could not mark as sold. ${e.message}`, 'error'); }
  };
  const withdraw = async (l) => {
    if (!(await confirmDialog({ title: 'Withdraw this listing?', message: `"${l.title}" will disappear from the marketplace.`, confirmLabel: 'Withdraw', danger: true }))) return;
    try { await listingsApi.setStatus(l.id, 'withdrawn'); toast('Listing withdrawn.'); load(); }
    catch (e) { toast(`Could not withdraw. ${e.message}`, 'error'); }
  };

  async function load() {
    body.replaceChildren(loading());
    try {
      const listings = await listingsApi.mine();
      if (!listings.length) { body.replaceChildren(empty('You have no listings yet', 'Publish your first animals to start getting offers.', h('a', { class: 'btn btn-primary', href: '#/new-listing' }, 'Create a listing'))); return; }
      body.replaceChildren(h('div', { class: 'grid' }, ...listings.map((l) => h('div', { class: 'stack-sm' }, listingCard(l, { showStatus: true }),
        l.status === 'active' ? h('div', { class: 'row' },
          h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: () => markSold(l) }, icon('check', 16), 'Mark as sold'),
          h('button', { class: 'btn btn-danger btn-sm', type: 'button', onclick: () => withdraw(l) }, 'Withdraw')) : null))));
    } catch (e) { body.replaceChildren(errorBox(`Could not load your listings. ${e.message}`, load)); }
  }
  load();

  return { title: 'My listings', node: h('div', { class: 'page' },
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'My listings'), h('p', null, 'Everything you have published, in any status.')),
      h('a', { class: 'btn btn-primary', href: '#/new-listing' }, icon('plus', 18), 'New listing')), body) };
}
