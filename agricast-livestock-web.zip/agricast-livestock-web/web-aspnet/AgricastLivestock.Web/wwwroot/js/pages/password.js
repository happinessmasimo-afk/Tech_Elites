import { h, field, withBusy } from '../ui.js';
import { forgotPassword, resetPassword, getRecoveryToken } from '../auth.js';
import { go } from '../router.js';

const shell = (title, sub, ...rest) => ({
  title,
  node: h('div', { class: 'split' },
    h('div', { class: 'split-art', style: { backgroundImage: "url('/img/login-bg.jpg')", backgroundPosition: '50% 70%' }, role: 'presentation' }),
    h('div', { class: 'split-body' }, h('div', { class: 'inner' }, h('div', { class: 'stack-sm' }, h('h1', null, title), h('p', { class: 'muted' }, sub)), ...rest))),
});

export async function forgotPasswordPage() {
  const email = h('input', { class: 'input', type: 'email', autocomplete: 'email', required: true, placeholder: 'you@example.com' });
  const msg = h('div', { class: 'form-msg', hidden: true, role: 'alert' });
  const submit = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Send reset link');
  const show = (t, k) => { msg.className = 'form-msg ' + k; msg.textContent = t; msg.hidden = false; };
  const form = h('form', { class: 'stack', novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    if (!email.value.trim()) return show('Enter your email address.', 'error');
    await withBusy(submit, async () => {
      try { const r = await forgotPassword(email.value.trim()); show(r.message || 'If that email has an account, a reset link is on its way.', 'ok'); }
      catch (err) { show(err.message, 'error'); }
    });
  } }, field('Email', email), msg, submit);
  return shell('Forgot your password?', "Enter your email and we'll send you a link to choose a new one.", form,
    h('p', { class: 'center muted' }, h('a', { href: '#/login' }, 'Back to log in')));
}

export async function resetPasswordPage() {
  if (!getRecoveryToken()) {
    return shell('Reset link expired', 'This reset link is missing or has already been used.',
      h('a', { class: 'btn btn-primary btn-block', href: '#/forgot-password' }, 'Request a new link'));
  }
  const pw = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', required: true });
  const pw2 = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', required: true });
  const msg = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
  const submit = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Save new password');
  const show = (t) => { msg.textContent = t; msg.hidden = false; };
  const form = h('form', { class: 'stack', novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    if (pw.value.length < 6) return show('Choose a password with at least 6 characters.');
    if (pw.value !== pw2.value) return show('The two passwords do not match.');
    await withBusy(submit, async () => {
      try { await resetPassword(pw.value); go('/login?reset=1'); }
      catch (err) { show(err.message); }
    });
  } }, field('New password', pw, 'At least 6 characters.'), field('Repeat new password', pw2), msg, submit);
  return shell('Choose a new password', 'Pick something you have not used before.', form);
}
