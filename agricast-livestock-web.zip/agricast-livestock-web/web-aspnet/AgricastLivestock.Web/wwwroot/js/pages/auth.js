import { h, field, withBusy } from '../ui.js';
import { login, register, homePath } from '../auth.js';
import { go } from '../router.js';

function safeNext(next) { return next && next.startsWith('/') && !next.startsWith('//') ? next : null; }

export async function loginPage({ query }) {
  const email = h('input', { class: 'input', type: 'email', autocomplete: 'email', required: true, placeholder: 'you@example.com' });
  const password = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', required: true });
  const msg = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
  const submit = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Log in');

  const form = h('form', { class: 'stack', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    msg.hidden = true;
    if (!email.value.trim() || !password.value) { msg.textContent = 'Enter your email and password.'; msg.hidden = false; return; }
    await withBusy(submit, async () => {
      try {
        await login(email.value.trim(), password.value);
        go(safeNext(query.next) || homePath());
      } catch (err) { msg.textContent = err.message; msg.hidden = false; }
    });
  } }, field('Email', email), field('Password', password), h('div', { class: 'right' }, h('a', { href: '#/forgot-password' }, 'Forgot your password?')), msg, submit);

  return {
    title: 'Log in',
    node: h('div', { class: 'split' },
      h('div', { class: 'split-art', style: { backgroundImage: "url('/img/login-bg.jpg')", backgroundPosition: '50% 70%' }, role: 'presentation' }),
      h('div', { class: 'split-body' }, h('div', { class: 'inner' },
        h('div', { class: 'stack-sm' }, h('h1', null, 'Welcome back'), h('p', { class: 'muted' }, 'Log in with your Agricast account.')),
        query.reset ? h('div', { class: 'form-msg ok' }, 'Password updated. Log in with your new password.') : null,
        form,
        h('p', { class: 'center muted' }, 'New here? ', h('a', { href: '#/register' }, 'Create an account'))))),
  };
}

export async function registerPage() {
  const name = h('input', { class: 'input', autocomplete: 'name', required: true });
  const email = h('input', { class: 'input', type: 'email', autocomplete: 'email', required: true });
  const phone = h('input', { class: 'input', type: 'tel', autocomplete: 'tel', required: true });
  const password = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', required: true });
  const msg = h('div', { class: 'form-msg', hidden: true, role: 'alert' });
  const submit = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Create account');
  const show = (text, kind) => { msg.className = 'form-msg ' + kind; msg.textContent = text; msg.hidden = false; };

  const form = h('form', { class: 'stack', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    msg.hidden = true;
    if (!name.value.trim() || !email.value.trim() || !phone.value.trim() || !password.value) return show('Fill in every field.', 'error');
    if (password.value.length < 6) return show('Choose a password with at least 6 characters.', 'error');
    await withBusy(submit, async () => {
      try {
        const r = await register({ fullName: name.value.trim(), email: email.value.trim(), phone: phone.value.trim(), password: password.value });
        if (r.signedIn) go(homePath());
        else show(r.message || 'Account created. We sent a confirmation link to your email. Open it to activate your account, then log in.', 'ok');
      } catch (err) { show(err.message, 'error'); }
    });
  } }, field('Full name', name), field('Email', email), field('Phone', phone), field('Password', password, 'At least 6 characters.'), msg, submit);

  return {
    title: 'Create account',
    node: h('div', { class: 'split' },
      h('div', { class: 'split-art', style: { backgroundImage: "url('/img/login-bg.jpg')", backgroundPosition: '50% 70%' }, role: 'presentation' }),
      h('div', { class: 'split-body' }, h('div', { class: 'inner' },
        h('div', { class: 'stack-sm' }, h('h1', null, 'Create your account'), h('p', { class: 'muted' }, 'Sign up to browse listings and make offers on livestock.')),
        form,
        h('p', { class: 'center muted' }, 'Already have an account? ', h('a', { href: '#/login' }, 'Log in'))))),
  };
}
