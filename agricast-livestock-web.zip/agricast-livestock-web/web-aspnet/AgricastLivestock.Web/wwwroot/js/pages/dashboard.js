import { h, icon, errorBox, loading, money, pill, formatDate } from '../ui.js';
import { listingsApi, financeApi, offersApi, deliveriesApi } from '../api.js';
import { auth } from '../auth.js';
import { latestDeliveries, onDeliveriesChange, notificationPrompt } from '../notifications.js';
import { addressText } from '../maps.js';

export async function dashboardPage() {
  const body = h('div');
  const deliveriesBox = h('div', { class: 'section' });
  let destroyed = false; let deliveries = [];

  const stat = (label, value, hot) => h('div', { class: `stat${hot ? ' hot' : ''}` }, h('div', { class: 'n' }, value), h('div', { class: 'l' }, label));
  const action = (href, ic, text) => h('a', { class: 'action', href }, icon(ic, 22), text);

  function paintDeliveries() {
    if (!deliveries.length) { deliveriesBox.replaceChildren(); return; }
    deliveriesBox.replaceChildren(
      h('div', { class: 'row' }, h('h2', null, 'Deliveries and pickups'), h('span', { class: 'badge' }, String(deliveries.length))),
      h('div', { class: 'card-list' }, ...deliveries.map((d) => {
        const isDelivery = d.method === 'delivery';
        const started = d.status === 'in_transit';
        return h('div', { class: 'card job' },
          h('div', { class: 'job-head' }, h('h3', null, `${isDelivery ? 'Deliver' : 'Pickup'}: ${d.listingTitle || 'order'}`),
            pill(started ? 'in_transit' : 'pending', started ? (isDelivery ? 'On the way' : 'Buyer on the way') : (isDelivery ? 'Not started' : 'Waiting for buyer'))),
          h('div', { class: 'muted' }, d.buyerName || 'Buyer', d.buyerPhone ? h('span', null, ', ', h('a', { href: `tel:${d.buyerPhone}` }, d.buyerPhone)) : null),
          isDelivery ? h('div', null, h('div', { class: 'muted small' }, 'Deliver to'), d.destLat !== null ? addressText(d.destLat, d.destLng, 'strong') : h('span', { class: 'muted' }, 'No address pinned')) : h('div', { class: 'muted' }, 'The buyer will collect it from your farm.'),
          h('div', null, h('a', { class: 'btn btn-primary btn-sm', href: `#/trip/${encodeURIComponent(d.id)}` }, isDelivery ? (started ? 'Continue trip' : 'Start trip') : 'Track buyer')));
      })));
  }

  async function loadDeliveries(list) {
    if (destroyed) return;
    if (!list) { try { list = await deliveriesApi.active(); } catch { return; } }
    deliveries = list; paintDeliveries();
  }

  async function load() {
    body.replaceChildren(loading());
    try {
      const [mine, finance, offers] = await Promise.all([listingsApi.mine(), financeApi.summary(), offersApi.mine()]);
      const active = mine.filter((l) => l.status === 'active').length;
      const pending = offers.filter((o) => o.status === 'pending').length;
      const first = auth.profile?.fullName ? auth.profile.fullName.split(' ')[0] : null;
      body.replaceChildren(
        h('div', { class: 'page-head' }, h('div', null, h('h1', null, `Welcome back${first ? ', ' + first : ''}`), h('p', null, "Here's how your farm is doing on Agricast."))),
        h('div', { class: 'stats' }, stat('Active listings', String(active)), stat('Total revenue', money(finance.totalRevenue)), stat('Sold', String(finance.soldCount)), stat('Pending offers', String(pending), pending > 0)),
        notificationPrompt(),
        deliveriesBox,
        h('div', { class: 'section' }, h('h2', null, 'Quick actions'), h('div', { class: 'actions' },
          action('#/new-listing', 'plus', 'New listing'), action('#/my-listings', 'list', 'My listings'), action('#/offers-received', 'mail', 'Offers received'),
          action('#/finance', 'chart', 'Finance'), action('#/marketplace', 'store', 'Browse marketplace'), action('#/profile/password', 'lock', 'Change password'))),
        h('div', { class: 'section' }, h('h2', null, 'Recently sold'),
          finance.soldListings.length ? h('div', { class: 'card-list' }, ...finance.soldListings.slice(0, 5).map((l) => h('div', { class: 'card line-item' },
            l.photoUrls[0] ? h('img', { class: 'thumb', src: l.photoUrls[0], alt: '' }) : h('div', { class: 'thumb' }),
            h('div', { class: 'grow' }, h('div', { style: { fontWeight: '700' } }, l.title), h('div', { class: 'muted small' }, l.species, l.soldAt ? ` sold ${formatDate(l.soldAt)}` : '')),
            h('div', { class: 'amt' }, money(l.soldPrice ?? l.askingPrice)))))
            : h('p', { class: 'muted' }, 'Nothing sold yet. Once you do, it shows up here.')));
      paintDeliveries();
    } catch (e) { body.replaceChildren(errorBox(`Could not load the dashboard. ${e.message}`, load)); }
  }

  load();
  loadDeliveries(latestDeliveries.length ? latestDeliveries : null);
  const off = onDeliveriesChange((l) => loadDeliveries(l));

  return { title: 'Dashboard', node: h('div', { class: 'page' }, body), leave: () => { destroyed = true; off(); } };
}
