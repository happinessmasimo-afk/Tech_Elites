import { h, icon, backLink, loading, errorBox, money, formatDate, toast, withBusy } from '../ui.js';
import { receiptsApi } from '../api.js';
import { auth } from '../auth.js';
import { addressText } from '../maps.js';

const unitLabel = { per_head: 'per head', per_kg: 'per kg', total: 'total' };

export async function receiptPage({ params }) {
  const body = h('div', null, loading());
  async function load() {
    body.replaceChildren(loading());
    let r;
    try { r = await receiptsApi.get(params.offerId); }
    catch (e) { body.replaceChildren(errorBox(e.status === 404 ? 'No slip yet. A slip is created once the order is paid.' : `Could not load the slip. ${e.message}`, load)); return; }
    const row = (k, v) => v === null || v === undefined || v === '' ? null : h('div', { class: 'slip-row' }, h('span', { class: 'muted' }, k), h('span', { class: 'slip-val' }, v));
    const fulfil = r.method === 'delivery' ? 'Delivery to buyer' : r.method === 'pickup' ? 'Pickup by buyer' : 'Not arranged yet';
    const emailBtn = h('button', { class: 'btn btn-outline', type: 'button' }, icon('mail', 18), 'Email me this slip');
    emailBtn.onclick = () => withBusy(emailBtn, async () => {
      try { await receiptsApi.email(r.offerId); toast('Slip sent to your email.', 'ok'); }
      catch (e) { toast(`Could not send the email. ${e.message}`, 'error'); }
    });
    const printBtn = h('button', { class: 'btn btn-outline', type: 'button', onclick: () => window.print() }, 'Print or save as PDF');
    body.replaceChildren(
      h('div', { class: 'slip card' },
        h('div', { class: 'slip-head' }, h('div', null, h('div', { class: 'muted small' }, 'Agricast Livestock'), h('h1', null, 'Purchase slip')),
          h('div', { class: 'slip-no' }, h('div', { class: 'muted small' }, 'Slip no.'), h('strong', null, r.slipNumber))),
        h('div', { class: 'slip-total' }, h('div', { class: 'muted small' }, 'Amount paid'), h('div', { class: 'slip-amt' }, money(r.amountPaid)),
          h('span', { class: 'pill method' }, r.method === 'delivery' ? 'Delivery' : r.method === 'pickup' ? 'Pickup' : 'Paid')),
        h('div', { class: 'slip-sec' }, row('Date', r.issuedAt ? formatDate(r.issuedAt) : null), row('Item', r.itemTitle),
          row('Species', [r.species, r.breed, r.sex].filter(Boolean).join(', ')), row('Quantity', String(r.quantity)),
          row('Price', `${money(r.unitPrice)} ${unitLabel[r.priceUnit] || ''}`.trim()), row('Located at', r.itemLocation)),
        h('div', { class: 'slip-sec' }, row('Buyer', r.buyerName), row('Buyer phone', r.buyerPhone), row('Buyer email', r.buyerEmail), row('Seller', r.sellerName),
          row('Fulfilment', fulfil), row(r.method === 'delivery' ? 'Delivered to' : r.method === 'pickup' ? 'Collect from' : null, r.lat !== null ? addressText(r.lat, r.lng) : null)),
        h('p', { class: 'muted small' }, 'Demo checkout: no real payment gateway was used.')),
      h('div', { class: 'row slip-actions' }, printBtn, emailBtn));
  }
  load();
  return { title: 'Purchase slip', node: h('div', { class: 'page narrow' }, backLink(auth.isFarmer ? '#/offers-received' : '#/my-offers', 'Back'), body) };
}
