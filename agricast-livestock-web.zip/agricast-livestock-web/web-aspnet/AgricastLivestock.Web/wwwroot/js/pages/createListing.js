import { h, icon, field, toast, withBusy, backLink, capitalize } from '../ui.js';
import { listingsApi, uploadsApi } from '../api.js';
import { go } from '../router.js';
import { pickLocation, coordsText } from '../maps.js';

const MAX_PHOTO = 8 * 1024 * 1024;

export async function createListingPage() {
  const photos = []; // { file, url }
  let pinned = null;

  const title = h('input', { class: 'input', placeholder: 'e.g. 6 Boer goats', required: true });
  const species = h('input', { class: 'input', placeholder: 'e.g. Cattle, Goat, Sheep', list: 'species-options', required: true });
  const speciesList = h('datalist', { id: 'species-options' }, ...['Cattle', 'Goat', 'Sheep', 'Pig', 'Chicken'].map((s) => h('option', { value: s })));
  const breed = h('input', { class: 'input' });
  const sex = h('select', { class: 'select' }, h('option', { value: 'male' }, 'Male'), h('option', { value: 'female' }, 'Female'), h('option', { value: 'mixed', selected: true }, 'Mixed'));
  const quantity = h('input', { class: 'input', type: 'number', min: '1', step: '1', value: '1' });
  const age = h('input', { class: 'input', type: 'number', min: '0', step: '1' });
  const weight = h('input', { class: 'input', type: 'number', min: '0', step: 'any' });
  const price = h('input', { class: 'input', type: 'number', min: '0', step: 'any', inputmode: 'decimal' });
  const unit = h('select', { class: 'select' }, h('option', { value: 'per_head' }, 'Per head'), h('option', { value: 'per_kg' }, 'Per kg'));
  const location = h('input', { class: 'input', placeholder: 'Town or area' });
  const description = h('textarea', { class: 'textarea' });
  const err = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
  const status = h('div', { class: 'form-msg ok', hidden: true, 'aria-live': 'polite' });
  const submit = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Publish listing');

  const photoGrid = h('div', { class: 'photos' });
  const fileInput = h('input', { type: 'file', accept: 'image/*', multiple: true, hidden: true, onchange: (e) => {
    for (const f of e.target.files) {
      if (!f.type.startsWith('image/')) continue;
      if (f.size > MAX_PHOTO) { toast(`${f.name} is larger than 8 MB and was skipped.`, 'error'); continue; }
      photos.push({ file: f, url: URL.createObjectURL(f) });
    }
    e.target.value = '';
    paintPhotos();
  } });
  function paintPhotos() {
    photoGrid.replaceChildren(
      ...photos.map((p, i) => h('div', { class: 'photo' }, h('img', { src: p.url, alt: `Photo ${i + 1}` }),
        h('button', { type: 'button', 'aria-label': `Remove photo ${i + 1}`, onclick: () => { URL.revokeObjectURL(p.url); photos.splice(i, 1); paintPhotos(); } }, '×'))),
      h('button', { class: 'photo-add', type: 'button', 'aria-label': 'Add photos', onclick: () => fileInput.click() }, icon('camera', 26)));
  }
  paintPhotos();

  const pinLabel = h('span', { class: 'muted small' });
  const pinBtn = h('button', { class: 'btn btn-outline', type: 'button', onclick: async () => {
    const r = await pickLocation({ title: 'Pin the exact location', initial: pinned });
    if (!r) return;
    pinned = r;
    if (!location.value.trim() && r.label) location.value = r.label;
    paintPin();
  } });
  function paintPin() {
    pinBtn.replaceChildren(icon('pin', 18), pinned ? 'Location pinned. Change it' : 'Pin exact location on map (optional)');
    pinLabel.textContent = pinned ? (pinned.label || coordsText(pinned.lat, pinned.lng)) : 'Buyers who choose delivery or pickup will be routed to this spot.';
  }
  paintPin();

  const fail = (m) => { err.textContent = m; err.hidden = false; };

  const form = h('form', { class: 'stack card', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    err.hidden = true; status.hidden = true;
    const q = parseInt(quantity.value, 10);
    const p = parseFloat(price.value);
    if (!title.value.trim()) return fail('Add a title.');
    if (!species.value.trim()) return fail('Add the species.');
    if (!Number.isInteger(q) || q < 1) return fail('Quantity must be at least 1.');
    if (!Number.isFinite(p) || p <= 0) return fail('Enter the asking price.');
    await withBusy(submit, async () => {
      try {
        const urls = [];
        for (let i = 0; i < photos.length; i++) {
          status.textContent = `Uploading photo ${i + 1} of ${photos.length}...`; status.hidden = false;
          urls.push(await uploadsApi.listingPhoto(photos[i].file));
        }
        status.textContent = 'Publishing...'; status.hidden = false;
        const listing = await listingsApi.create({
          title: title.value.trim(), species: species.value.trim(), breed: breed.value.trim() || null, sex: sex.value,
          quantity: q, ageMonths: age.value.trim() ? parseInt(age.value, 10) : null, weightKg: weight.value.trim() ? parseFloat(weight.value) : null,
          askingPrice: p, priceUnit: unit.value, description: description.value.trim() || null, location: location.value.trim() || null,
          photoUrls: urls, latitude: pinned ? pinned.lat : null, longitude: pinned ? pinned.lng : null,
        });
        photos.forEach((x) => URL.revokeObjectURL(x.url));
        toast('Listing published.', 'ok');
        go(`/listing/${encodeURIComponent(listing.id)}`);
      } catch (e2) { status.hidden = true; fail(e2.message); }
    });
  } },
    h('div', { class: 'field' }, h('span', { class: 'label' }, 'Photos'), photoGrid, fileInput, h('span', { class: 'hint' }, 'Add as many as you like, up to 8 MB each.')),
    field('Title', title), h('div', { class: 'field-row' }, field('Species', species), field('Breed (optional)', breed)), speciesList,
    h('div', { class: 'field-row' }, field('Sex', sex), field('Quantity', quantity)),
    h('div', { class: 'field-row' }, field('Age in months (optional)', age), field('Weight in kg, per animal (optional)', weight)),
    h('div', { class: 'field-row' }, field('Asking price (R)', price), field('Price unit', unit)),
    field('Location (optional)', location),
    h('div', { class: 'stack-sm' }, pinBtn, pinLabel),
    field('Description (optional)', description),
    err, status, h('div', { class: 'row' }, submit, h('a', { class: 'btn btn-outline', href: '#/my-listings' }, 'Cancel')));

  return { title: 'New listing', node: h('div', { class: 'page medium' }, backLink('#/my-listings', 'My listings'), h('div', { class: 'page-head' }, h('h1', null, 'New listing')), form) };
}
