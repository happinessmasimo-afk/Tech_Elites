import { h, icon, field, money, backLink, spinner } from '../ui.js';
import { offersApi, paymentsApi } from '../api.js';
import { go } from '../router.js';

// A demo checkout (same as the app): no real gateway, only the last 4 card digits are sent.
export async function checkoutPage({ params }) {
  const offers = await offersApi.mine();
  const offer = offers.find((o) => o.id === params.offerId);
  const root = h('div', { class: 'page narrow' });
  if (!offer) {
    root.append(backLink('#/my-offers', 'My offers'), h('div', { class: 'error-box' }, 'We could not find that order. It may belong to a different account.'));
    return { title: 'Checkout', node: root };
  }

  let step = offer.paymentStatus === 'paid' ? 'paid' : 'summary';
  let error = '';
  const amount = offer.amount;

  const bars = (n) => h('div', { class: 'steps', 'aria-hidden': 'true' }, [1, 2, 3].map((i) => h('span', { class: i <= n ? 'on' : '' })));

  async function pay(values) {
    step = 'processing'; error = ''; draw();
    const digits = values.number.replace(/\s/g, '');
    try {
      await paymentsApi.pay(offer.id, values.name, digits.slice(-4));
      step = 'success';
    } catch (e) { step = 'card'; error = `Payment failed. ${e.message}`; }
    draw();
  }

  function draw() {
    if (step === 'summary') {
      root.replaceChildren(backLink('#/my-offers', 'My offers'), bars(1), h('div', { class: 'stack' },
        h('h1', null, 'Order summary'),
        h('div', { class: 'card' }, h('h3', null, offer.listingTitle || 'Listing'), h('div', { class: 'summary-row' }, h('span', { class: 'muted' }, 'Amount'), h('span', { class: 'amt' }, money(amount)))),
        h('p', { class: 'muted small' }, 'This is a demo checkout. No real payment gateway is used and no real money moves.'),
        h('button', { class: 'btn btn-primary btn-block', type: 'button', onclick: () => { step = 'card'; draw(); } }, 'Continue to payment')));
    } else if (step === 'card') {
      const name = h('input', { class: 'input', autocomplete: 'cc-name', value: '' });
      const number = h('input', { class: 'input', inputmode: 'numeric', autocomplete: 'cc-number', maxlength: '23', placeholder: '1234 5678 9012 3456', oninput: (e) => {
        e.target.value = e.target.value.replace(/\D/g, '').slice(0, 19).replace(/(.{4})/g, '$1 ').trim();
      } });
      const expiry = h('input', { class: 'input', inputmode: 'numeric', autocomplete: 'cc-exp', maxlength: '5', placeholder: 'MM/YY', oninput: (e) => {
        const d = e.target.value.replace(/\D/g, '').slice(0, 4);
        e.target.value = d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
      } });
      const cvv = h('input', { class: 'input', inputmode: 'numeric', autocomplete: 'cc-csc', maxlength: '4', placeholder: '123', type: 'password' });
      const err = h('div', { class: 'form-msg error', role: 'alert', hidden: !error }, error);
      root.replaceChildren(backLink('#/my-offers', 'My offers'), bars(2), h('form', { class: 'stack', novalidate: true, onsubmit: (e) => {
        e.preventDefault();
        if (!name.value.trim() || number.value.replace(/\s/g, '').length < 12 || !expiry.value.trim() || cvv.value.trim().length < 3) {
          err.textContent = 'Fill in all card details. Any values work, this is a demo.'; err.hidden = false; return;
        }
        pay({ name: name.value.trim(), number: number.value });
      } },
        h('h1', null, 'Card details'), h('p', { class: 'muted small' }, 'Enter anything. This is a simulated payment.'),
        field('Cardholder name', name), field('Card number', number),
        h('div', { class: 'field-row' }, field('Expiry', expiry), field('CVV', cvv)), err,
        h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, `Pay ${money(amount)}`)));
    } else if (step === 'processing') {
      root.replaceChildren(bars(2), h('div', { class: 'loading' }, spinner(), 'Processing payment...'));
    } else if (step === 'success') {
      root.replaceChildren(bars(3), h('div', { class: 'stack center' },
        h('div', { class: 'success-mark' }, icon('check', 38)),
        h('h1', null, 'Payment successful'),
        h('p', { class: 'muted' }, 'The farmer has been notified and this listing is now marked sold.'),
        h('button', { class: 'btn btn-primary btn-block', type: 'button', onclick: () => go(`/delivery/${encodeURIComponent(offer.id)}`) }, 'Arrange delivery or pickup'),
        h('a', { class: 'btn btn-outline btn-block', href: `#/receipt/${encodeURIComponent(offer.id)}` }, 'View my slip (also emailed to you)'),
        h('a', { class: 'btn btn-outline btn-block', href: '#/my-offers' }, "I'll do this later")));
    } else {
      root.replaceChildren(backLink('#/my-offers', 'My offers'), h('div', { class: 'stack center' },
        h('div', { class: 'success-mark' }, icon('check', 38)), h('h1', null, 'Already paid'),
        h('a', { class: 'btn btn-primary btn-block', href: `#/delivery/${encodeURIComponent(offer.id)}` }, 'Arrange delivery or pickup')));
    }
  }
  draw();
  return { title: 'Checkout', node: root };
}
