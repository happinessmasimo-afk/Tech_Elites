import { h, icon, backLink, toast, withBusy, pill, money } from '../ui.js';
import { deliveriesApi, offersApi, mergeDelivery } from '../api.js';
import { auth } from '../auth.js';
import { mountMap, addressText, createRouteTracker, navigationUrl } from '../maps.js';

// One route serves both sides of a trip. Whoever physically travels
// (buyer for a pickup, farmer for a delivery) gets the "traveller" view:
// it shares live GPS and shows the road to the destination like a navigator.
// The other person gets the "watcher" view, which follows the traveller on
// the same road, with the same ETA, and is told when the trip starts.
export async function tripPage({ params }) {
  const first = await deliveriesApi.get(params.id);
  let offer = null;
  try { offer = (await offersApi.mine()).find((o) => o.id === first.offerId) || null; } catch { /* the order panel is optional */ }
  return first.travelerId === auth.userId ? travelerView(first, offer) : watcherView(first, offer);
}

// ---------------------------------------------------------------- helpers
const point = (lat, lng) => (lat !== null && lat !== undefined && lng !== null && lng !== undefined ? { lat, lng } : null);

function duration(min) {
  if (min < 60) return `${min} min`;
  const hrs = Math.floor(min / 60); const rest = min % 60;
  return rest ? `${hrs} h ${rest} min` : `${hrs} h`;
}

// Big "how long" panel. Prefers the fresh road route from Mapbox; falls back to what the server last stored.
function etaBlock(route, d) {
  const minutes = route ? route.minutes : d.etaMinutes;
  const km = route ? route.distanceKm : d.distanceKm;
  if (minutes === null && km === null) return null;
  const arrive = minutes !== null && minutes !== undefined
    ? new Date(Date.now() + minutes * 60000).toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' }) : null;
  return h('div', { class: 'eta', 'aria-live': 'polite' },
    minutes !== null && minutes !== undefined ? h('div', { class: 'eta-main' }, duration(minutes)) : null,
    h('div', { class: 'eta-sub' },
      km !== null && km !== undefined ? h('span', null, `${km.toFixed(1)} km to go`) : null,
      arrive ? h('span', null, `Arrives about ${arrive}`) : null));
}

// "This customer bought this, for this much, as a delivery or a pickup."
function orderCard(d, offer) {
  const pickup = d.method === 'pickup';
  const title = d.listingTitle || (offer && offer.listingTitle) || 'Order';
  const buyerName = d.buyerName || (offer && offer.buyerName);
  const buyerPhone = d.buyerPhone || (offer && offer.buyerPhone);
  const dest = point(d.destLat, d.destLng);
  const row = (k, v) => h('div', { class: 'order-row' }, h('span', { class: 'muted' }, k), h('span', { class: 'order-val' }, v));
  return h('div', { class: 'card stack-sm order-card' },
    h('div', { class: 'row between' }, h('h3', null, title), h('span', { class: 'pill method' }, pickup ? 'Pickup' : 'Delivery')),
    offer ? row('Paid', money(offer.amount)) : null,
    auth.isFarmer && buyerName ? row('Buyer', h('span', null, buyerName, buyerPhone ? h('span', null, ' ', h('a', { href: `tel:${buyerPhone}` }, buyerPhone)) : null)) : null,
    row(pickup ? 'Collect from' : 'Deliver to', dest ? addressText(dest.lat, dest.lng) : h('span', { class: 'muted' }, pickup ? 'Farm location not pinned' : 'No address pinned')),
    offer ? h('a', { class: 'btn btn-outline btn-sm', href: `#/receipt/${encodeURIComponent(offer.id)}` }, 'View slip') : null);
}

// ---------------------------------------------------------------- watcher
async function watcherView(initial, offer) {
  let d = initial; let route = null;
  const pickup = d.method === 'pickup';
  const travelerName = pickup ? 'The buyer' : 'The farmer';
  const mapBox = h('div', { class: 'trip-map' });
  const side = h('div', { class: 'stack' });
  let map = null; let timer = null; let destroyed = false; let fittedOnce = false; let routeFitted = false;

  const tracker = createRouteTracker((r) => {
    route = r;
    if (map && map.ok) { map.setRoute(r ? r.coords : [], { fit: !!r && !routeFitted }); if (r) routeFitted = true; }
    if (!destroyed) paintSide();
  });

  const dest = () => point(d.destLat, d.destLng);
  const origin = () => point(d.travelerLat, d.travelerLng);

  function refreshMap() {
    if (!map || !map.ok) return;
    const markers = [];
    if (dest()) markers.push({ ...dest(), kind: 'flag', label: pickup ? 'Farm' : 'Delivery address' });
    if (origin()) markers.push({ ...origin(), kind: d.status === 'pending' ? 'pin' : 'mover', label: d.status === 'pending' ? (pickup ? 'Buyer' : 'Farm (start)') : travelerName });
    map.setMarkers(markers, { fit: !fittedOnce && markers.length > 0 });
    if (markers.length) fittedOnce = true;
    if (d.status === 'delivered') { map.setRoute([]); return; }
    tracker.update(origin(), dest());
  }

  const steps = () => {
    const started = d.status === 'in_transit' || d.status === 'delivered';
    const finished = d.status === 'delivered';
    return pickup
      ? [['Paid', true], ['Buyer chose to collect it', true], ['Buyer is on the way', started], ['Picked up', finished]]
      : [['Paid', true], ['Farmer has your delivery request', true], ['Farmer is on the way', started], ['Delivered', finished]];
  };

  function banner() {
    if (d.status === 'delivered') return h('div', { class: 'banner ok' }, pickup ? 'Picked up. All done.' : 'Delivered. All done.');
    if (d.status === 'in_transit') return h('div', { class: 'banner live' }, h('span', { class: 'live-dot' }), pickup ? 'The buyer is on the way to collect.' : 'The farmer has started the trip and is on the way.');
    return h('div', { class: 'banner wait' }, pickup ? 'Waiting for the buyer to set off.' : "The farmer hasn't set off yet. You'll see them here the moment they do.");
  }

  function paintSide() {
    const list = steps();
    const nowIdx = list.findIndex(([, done]) => !done);
    side.replaceChildren(
      h('div', { class: 'row between' }, h('h2', null, pickup ? 'Track the buyer' : 'Track your delivery'), pill(d.status)),
      banner(),
      d.status !== 'delivered' ? etaBlock(route, d) : null,
      orderCard(d, offer),
      h('div', { class: 'card' }, h('ul', { class: 'timeline' }, list.map(([text, done], i) => h('li', { class: done ? 'done' : i === nowIdx ? 'now' : '' }, h('span', { class: 'dot' }, done ? icon('check', 12) : null), text)))));
  }

  async function poll() {
    if (destroyed) return;
    try {
      const next = mergeDelivery(await deliveriesApi.get(d.id), d);
      const wasPending = d.status === 'pending';
      d = next;
      if (wasPending && d.status === 'in_transit') toast(pickup ? 'The buyer has set off to collect it.' : 'The farmer has started your delivery.', 'ok');
      paintSide(); refreshMap();
      if (d.status === 'delivered' && timer) { clearInterval(timer); timer = null; }
    } catch { /* a missed check is fine; the next one tries again */ }
  }

  const node = h('div', { class: 'page' }, backLink(auth.isFarmer ? '#/offers-received' : '#/my-offers', auth.isFarmer ? 'Offers received' : 'My offers'), h('div', { class: 'trip' }, mapBox, side));
  paintSide();
  return {
    title: pickup ? 'Track the buyer' : 'Track your delivery', node,
    mounted: async () => { map = await mountMap(mapBox, {}); refreshMap(); if (d.status !== 'delivered') timer = setInterval(poll, 6000); },
    leave: () => { destroyed = true; if (timer) clearInterval(timer); if (map) map.destroy(); },
  };
}

// --------------------------------------------------------------- traveller
async function travelerView(initial, offer) {
  let d = initial; let route = null; let me = null;
  const pickup = d.method === 'pickup';
  const labels = {
    start: pickup ? 'Start pickup journey' : 'Start delivery',
    finish: pickup ? "I've arrived: mark picked up" : 'Mark as delivered',
    travelling: pickup ? "You're on your way to collect it." : "You're on your way to deliver it.",
  };
  const mapBox = h('div', { class: 'trip-map' });
  const side = h('div', { class: 'stack' });
  const errBox = h('div', { class: 'form-msg error', hidden: true, role: 'alert' });
  let map = null; let watchId = null; let lastPush = 0; let destroyed = false; let busy = false; let fittedOnce = false; let routeFitted = false; let fittedMe = false;

  const setError = (m) => { errBox.textContent = m || ''; errBox.hidden = !m; };
  const dest = () => point(d.destLat, d.destLng);
  // Where the road starts: my live position, else the last position the server has for me (the farm, for a delivery not yet started).
  const origin = () => me || point(d.travelerLat, d.travelerLng);

  const tracker = createRouteTracker((r) => {
    route = r;
    if (map && map.ok) { map.setRoute(r ? r.coords : [], { fit: !!r && !routeFitted }); if (r) routeFitted = true; }
    if (!destroyed) paint();
  });

  function refreshMap() {
    if (!map || !map.ok) return;
    const markers = [];
    if (dest()) markers.push({ ...dest(), kind: 'flag', label: pickup ? 'Farm' : 'Delivery address' });
    if (me) markers.push({ ...me, kind: 'mover', label: 'You' });
    else if (origin()) markers.push({ ...origin(), kind: 'pin', label: 'Farm (start)' });
    map.setMarkers(markers, { fit: !fittedOnce || (!!me && !fittedMe) });
    if (markers.length) fittedOnce = true;
    if (me) fittedMe = true;
    if (d.status === 'delivered') { map.setRoute([]); return; }
    tracker.update(origin(), dest());
  }

  function paint() {
    const started = d.status === 'in_transit';
    const done = d.status === 'delivered';
    const from = origin(); const to = dest();
    const startBtn = h('button', { class: 'btn btn-primary btn-block', type: 'button' }, labels.start);
    startBtn.onclick = () => withBusy(startBtn, start);
    const finishBtn = h('button', { class: 'btn btn-primary btn-block', type: 'button' }, labels.finish);
    finishBtn.onclick = () => withBusy(finishBtn, finish);

    side.replaceChildren(
      h('div', { class: 'row between' }, h('h2', null, pickup ? 'Pick up your order' : 'Deliver to buyer'), pill(d.status)),
      done ? h('div', { class: 'banner ok' }, pickup ? 'Picked up. All done.' : 'Delivered. All done.')
        : started ? h('div', { class: 'banner live' }, h('span', { class: 'live-dot' }), labels.travelling)
          : h('div', { class: 'banner wait' }, me ? 'Your position is on the map. Start when you are ready to leave.' : 'Start when you are ready to leave. Your browser will ask to share your location.'),
      !done ? etaBlock(route, d) : null,
      orderCard(d, offer),
      to && !done ? h('a', { class: 'btn btn-outline btn-block', href: navigationUrl(from, to), target: '_blank', rel: 'noopener' }, icon('navigate', 18), 'Open turn-by-turn in Google Maps') : null,
      errBox,
      done ? null : started ? finishBtn : startBtn,
      !started && !done ? h('p', { class: 'muted small' }, 'Once you start, the other person sees you on the map with the road and your arrival time.') : null);
    refreshMap();
  }

  async function start() {
    setError('');
    try { d = mergeDelivery(await deliveriesApi.start(d.id), d); }
    catch (e) { setError(`Could not start the trip. ${e.message}`); return; }
    paint();
    beginSharing();
  }

  function beginSharing() {
    if (watchId !== null || destroyed) return;
    if (!navigator.geolocation) { setError('This browser cannot share your location. Open the app in a modern browser.'); return; }
    watchId = navigator.geolocation.watchPosition(async (pos) => {
      me = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      refreshMap();
      const now = Date.now();
      if (now - lastPush < 5000 || busy) return;
      lastPush = now;
      try { d = mergeDelivery(await deliveriesApi.location(d.id, me.lat, me.lng), d); setError(''); if (!destroyed) paint(); }
      catch (e) { setError(`Could not send your position. ${e.message}`); }
    }, (e) => {
      setError(e.code === 1 ? 'Location permission is needed to share your live position. Allow it in the browser address bar, then reload.' : 'Could not read your location. Check that location services are on.');
    }, { enableHighAccuracy: true, maximumAge: 4000, timeout: 20000 });
  }

  function stopSharing() { if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; } }

  async function finish() {
    setError(''); busy = true;
    try { stopSharing(); d = mergeDelivery(await deliveriesApi.status(d.id, 'delivered'), d); toast(pickup ? 'Marked as picked up.' : 'Marked as delivered.', 'ok'); }
    catch (e) { setError(`Could not update the trip. ${e.message}`); beginSharing(); }
    finally { busy = false; }
    paint();
  }

  const node = h('div', { class: 'page' }, backLink(auth.isFarmer ? '#/dashboard' : '#/my-offers', auth.isFarmer ? 'Dashboard' : 'My offers'), h('div', { class: 'trip' }, mapBox, side));
  paint();
  return {
    title: pickup ? 'Pick up your order' : 'Deliver to buyer', node,
    mounted: async () => {
      map = await mountMap(mapBox, {});
      refreshMap();
      if (d.status === 'in_transit') beginSharing();
      // Show where I am right away (and a road preview with ETA) before the trip starts.
      else if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((pos) => { if (destroyed || me) return; me = { lat: pos.coords.latitude, lng: pos.coords.longitude }; paint(); },
          () => { /* permission is asked again when the trip starts */ }, { timeout: 10000, maximumAge: 60000 });
      }
    },
    leave: () => { destroyed = true; stopSharing(); if (map) map.destroy(); },
  };
}
