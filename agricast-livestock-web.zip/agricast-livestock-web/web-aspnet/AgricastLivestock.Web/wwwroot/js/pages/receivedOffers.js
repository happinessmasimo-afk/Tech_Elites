import { h, empty, errorBox, loading, toast, openModal, pill, money, formatDate, icon } from '../ui.js';
import { offersApi, deliveriesApi } from '../api.js';
import { go } from '../router.js';

export function declineDialog() {
  return new Promise((resolve) => {
    openModal((close) => {
      const reason = h('textarea', { class: 'textarea', placeholder: 'e.g. Price is too low for this animal', 'aria-label': 'Reason for declining' });
      const err = h('div', { class: 'form-msg error', hidden: true });
      return [
        h('h2', null, 'Decline this offer'), h('p', { class: 'muted small' }, 'Tell the buyer why. They will see this.'), reason, err,
        h('div', { class: 'modal-actions' },
          h('button', { class: 'btn btn-outline', type: 'button', onclick: () => close(null) }, 'Cancel'),
          h('button', { class: 'btn btn-danger', type: 'button', onclick: () => {
            const t = reason.value.trim();
            if (t.length < 3) { err.textContent = 'Please give a reason.'; err.hidden = false; return; }
            close(t);
          } }, 'Decline offer')),
      ];
    }, { onClose: (r) => resolve(typeof r === 'string' ? r : null) });
  });
}

export async function receivedOffersPage() {
  const body = h('div');

  const respond = async (offer, status) => {
    try { await offersApi.update(offer.id, status); toast(status === 'accepted' ? 'Offer accepted. The buyer can now pay.' : 'Offer updated.', 'ok'); load(); }
    catch (e) { toast(`Could not update the offer. ${e.message}`, 'error'); }
  };
  const decline = async (offer) => {
    const reason = await declineDialog();
    if (reason === null) return;
    try { await offersApi.update(offer.id, 'declined', reason); toast('Offer declined.'); load(); }
    catch (e) { toast(`Could not decline the offer. ${e.message}`, 'error'); }
  };
  const openDelivery = async (offer) => {
    try {
      const d = await deliveriesApi.byOffer(offer.id);
      if (d.status === 'delivered') { toast(d.method === 'pickup' ? 'Already marked picked up.' : 'Already marked delivered.'); return; }
      go(`/trip/${encodeURIComponent(d.id)}`);
    } catch (e) {
      toast(e.status === 404 ? "The buyer hasn't arranged delivery or pickup yet." : e.message, e.status === 404 ? '' : 'error');
    }
  };

  async function load() {
    body.replaceChildren(loading());
    try {
      const offers = await offersApi.mine();
      if (!offers.length) { body.replaceChildren(empty('No offers yet', 'When a buyer makes an offer or buys one of your listings, it shows up here.')); return; }
      body.replaceChildren(h('div', { class: 'card-list' }, ...offers.map((o) => h('div', { class: 'card offer' },
        h('div', { class: 'row between' }, h('h3', null, h('a', { href: `#/listing/${encodeURIComponent(o.listingId)}`, style: { color: 'inherit', textDecoration: 'none' } }, o.listingTitle || 'Listing')), pill(o.paymentStatus === 'paid' ? 'paid' : o.status)),
        h('div', { class: 'muted' }, `From ${o.buyerName || 'a buyer'}`, o.buyerPhone ? h('span', null, ', ', h('a', { href: `tel:${o.buyerPhone}` }, o.buyerPhone)) : null, o.createdAt ? `. ${formatDate(o.createdAt)}` : ''),
        o.offerPrice !== null ? h('div', { class: 'price' }, `Offer: ${money(o.offerPrice)}`) : null,
        o.message ? h('div', { class: 'quote' }, o.message) : null,
        o.status === 'pending' ? h('div', { class: 'row' },
          h('button', { class: 'btn btn-danger btn-sm', type: 'button', onclick: () => decline(o) }, 'Decline'),
          h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => respond(o, 'accepted') }, 'Accept')) : null,
        o.status === 'accepted' && o.paymentStatus !== 'paid' ? h('p', { class: 'muted small' }, 'Accepted. Waiting for the buyer to pay.') : null,
        o.paymentStatus === 'paid' ? h('div', { class: 'row' }, h('a', { class: 'btn btn-outline btn-sm', href: `#/receipt/${encodeURIComponent(o.id)}` }, 'View slip'), h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: () => openDelivery(o) }, icon('truck', 16), 'Delivery or pickup')) : null))));
    } catch (e) { body.replaceChildren(errorBox(`Could not load offers. ${e.message}`, load)); }
  }
  load();

  return { title: 'Offers received', node: h('div', { class: 'page medium' }, h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Offers received'), h('p', null, 'Accept, decline, and follow up on paid orders.'))), body) };
}
