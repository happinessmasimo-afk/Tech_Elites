import { h, icon, field, empty, errorBox, loading, debounce } from '../ui.js';
import { listingsApi } from '../api.js';
import { auth } from '../auth.js';
import { listingCard } from '../components.js';

const SORTS = {
  newest: ['Newest first', (a, b) => (b.createdAt || 0) - (a.createdAt || 0)],
  oldest: ['Oldest first', (a, b) => (a.createdAt || 0) - (b.createdAt || 0)],
  low: ['Price: low to high', (a, b) => a.askingPrice - b.askingPrice],
  high: ['Price: high to low', (a, b) => b.askingPrice - a.askingPrice],
};

const blankFilter = () => ({ q: '', species: null, sex: null, breed: '', location: '', minPrice: null, maxPrice: null, minAge: null, maxAge: null, minWeight: null, maxWeight: null });

function matches(f, l) {
  const has = (hay, needle) => (hay || '').toLowerCase().includes(needle.trim().toLowerCase());
  if (f.q.trim() && ![l.title, l.species, l.breed, l.location, l.description].some((x) => has(x, f.q))) return false;
  if (f.species && l.species.toLowerCase() !== f.species.toLowerCase()) return false;
  if (f.sex && (l.sex || '').toLowerCase() !== f.sex) return false;
  if (f.breed.trim() && !has(l.breed, f.breed)) return false;
  if (f.location.trim() && !has(l.location, f.location)) return false;
  if (f.minPrice !== null && l.askingPrice < f.minPrice) return false;
  if (f.maxPrice !== null && l.askingPrice > f.maxPrice) return false;
  // A listing that doesn't state age/weight can't be shown to fit a range, so it is left out once that filter is on.
  if (f.minAge !== null || f.maxAge !== null) {
    if (l.ageMonths === null) return false;
    if (f.minAge !== null && l.ageMonths < f.minAge) return false;
    if (f.maxAge !== null && l.ageMonths > f.maxAge) return false;
  }
  if (f.minWeight !== null || f.maxWeight !== null) {
    if (l.weightKg === null) return false;
    if (f.minWeight !== null && l.weightKg < f.minWeight) return false;
    if (f.maxWeight !== null && l.weightKg > f.maxWeight) return false;
  }
  return true;
}

function activeCount(f) {
  return [f.species, f.sex, f.breed.trim(), f.location.trim(), f.minPrice !== null || f.maxPrice !== null, f.minAge !== null || f.maxAge !== null, f.minWeight !== null || f.maxWeight !== null].filter(Boolean).length;
}

const numOrNull = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };

export async function marketplacePage() {
  let all = [];
  let sort = 'newest';
  const filter = blankFilter();

  const grid = h('div', { class: 'grid' });
  const resultNote = h('p', { class: 'muted small', 'aria-live': 'polite' });
  const body = h('div');
  const speciesChips = h('div', { class: 'chips' });
  const toggleBadge = h('span', { class: 'badge', hidden: true });
  const rail = h('aside', { class: 'rail', 'aria-label': 'Filters' });
  const toggle = h('button', { class: 'btn btn-outline btn-sm filter-toggle', type: 'button', 'aria-expanded': 'false', onclick: () => {
    const open = rail.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  } }, icon('filter', 16), 'Filters', toggleBadge);

  const redraw = () => {
    const shown = all.filter((l) => matches(filter, l)).sort(SORTS[sort][1]);
    const n = activeCount(filter);
    toggleBadge.hidden = n === 0;
    toggleBadge.textContent = String(n);
    resultNote.textContent = all.length ? `${shown.length} of ${all.length} listing${all.length === 1 ? '' : 's'}` : '';
    if (!all.length) {
      grid.replaceChildren(empty('No livestock listed yet', 'Check back soon.', auth.isFarmer ? h('a', { class: 'btn btn-primary', href: '#/new-listing' }, 'Create the first listing') : null));
      grid.className = '';
    } else if (!shown.length) {
      grid.className = '';
      grid.replaceChildren(empty('Nothing matches those filters', 'Try widening the price range or clearing a filter.', h('button', { class: 'btn btn-outline', type: 'button', onclick: resetAll }, 'Reset filters')));
    } else {
      grid.className = 'grid';
      grid.replaceChildren(...shown.map((l) => listingCard(l)));
    }
  };
  const redrawDebounced = debounce(redraw, 120);

  const chipGroup = (options, getter, setter) => {
    const wrap = h('div', { class: 'chips' });
    const paint = () => wrap.replaceChildren(...options.map(([value, text]) =>
      h('button', { class: 'chip', type: 'button', 'aria-pressed': String(getter() === value), onclick: () => { setter(value); paint(); redraw(); } }, text)));
    paint();
    wrap.repaint = paint;
    return wrap;
  };

  const rangeRow = (label, minKey, maxKey, unit) => {
    const mk = (key, ph) => h('input', { class: 'input', type: 'number', min: '0', step: 'any', inputmode: 'decimal', placeholder: ph, 'aria-label': `${label}, ${ph}`, oninput: (e) => { filter[key] = numOrNull(e.target.value); redrawDebounced(); } });
    const a = mk(minKey, 'Min'), b = mk(maxKey, 'Max');
    a.dataset.key = minKey; b.dataset.key = maxKey;
    return h('div', { class: 'field' }, h('span', { class: 'label' }, unit ? `${label} (${unit})` : label), h('div', { class: 'range' }, a, h('span', { class: 'muted' }, 'to'), b));
  };

  const textFilter = (label, key, placeholder) => field(label, h('input', { class: 'input', type: 'text', placeholder, oninput: (e) => { filter[key] = e.target.value; redrawDebounced(); } }));

  const sexChips = chipGroup([[null, 'Any'], ['male', 'Male'], ['female', 'Female'], ['mixed', 'Mixed']], () => filter.sex, (v) => { filter.sex = v; });

  const resetAll = () => {
    Object.assign(filter, blankFilter());
    rail.querySelectorAll('input').forEach((i) => { i.value = ''; });
    search.value = '';
    sexChips.repaint();
    paintSpecies();
    redraw();
  };

  const paintSpecies = () => {
    // Species options come from what is actually listed right now.
    const seen = new Set(); const species = [];
    for (const l of all) { const k = l.species.trim().toLowerCase(); if (k && !seen.has(k)) { seen.add(k); species.push(l.species.trim()); } }
    species.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
    const opts = [[null, 'Any'], ...species.map((s) => [s, s])];
    const same = (a, b) => (a === null ? b === null : b !== null && a.toLowerCase() === b.toLowerCase());
    speciesChips.replaceChildren(...opts.map(([value, text]) =>
      h('button', { class: 'chip', type: 'button', 'aria-pressed': String(same(filter.species, value)), onclick: () => { filter.species = value; paintSpecies(); redraw(); } }, text)));
  };

  rail.append(
    h('div', { class: 'row between' }, h('h3', null, 'Filter listings'), h('button', { class: 'btn btn-sm', style: { color: 'var(--dust)' }, type: 'button', onclick: resetAll }, 'Reset')),
    h('div', { class: 'field' }, h('span', { class: 'label' }, 'Species'), speciesChips),
    h('div', { class: 'field' }, h('span', { class: 'label' }, 'Sex'), sexChips),
    textFilter('Breed', 'breed', 'e.g. Boer'),
    textFilter('Location', 'location', 'e.g. Free State'),
    rangeRow('Price', 'minPrice', 'maxPrice', 'R'),
    rangeRow('Age', 'minAge', 'maxAge', 'months'),
    rangeRow('Weight', 'minWeight', 'maxWeight', 'kg'));

  const search = h('input', { class: 'input search', type: 'search', placeholder: 'Search title, breed or place', 'aria-label': 'Search listings', oninput: (e) => { filter.q = e.target.value; redrawDebounced(); } });
  const sortSel = h('select', { class: 'select', 'aria-label': 'Sort listings', onchange: (e) => { sort = e.target.value; redraw(); } },
    ...Object.entries(SORTS).map(([k, [text]]) => h('option', { value: k }, text)));

  const load = async () => {
    body.replaceChildren(loading('Loading listings...'));
    try {
      all = await listingsApi.active();
      paintSpecies();
      body.replaceChildren(h('div', { class: 'toolbar' }, search, sortSel, toggle), resultNote, h('div', { style: { height: '10px' } }), grid);
      redraw();
    } catch (e) { body.replaceChildren(errorBox(`Could not load listings. ${e.message}`, load)); }
  };

  const node = h('div', { class: 'page' },
    h('div', { class: 'page-head' },
      h('div', null, h('h1', null, 'Marketplace'), h('p', null, 'Livestock for sale straight from the farm.')),
      auth.isFarmer ? h('a', { class: 'btn btn-primary', href: '#/new-listing' }, icon('plus', 18), 'New listing') : null),
    h('div', { class: 'market' }, rail, body));
  load();
  return { title: 'Marketplace', node };
}
