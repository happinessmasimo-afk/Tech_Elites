import { h, empty, errorBox, loading, toast, confirmDialog, pill, money, formatDate, icon } from '../ui.js';
import { offersApi, deliveriesApi } from '../api.js';
import { go } from '../router.js';

export async function myOffersPage() {
  const body = h('div');

  const withdraw = async (o) => {
    if (!(await confirmDialog({ title: 'Withdraw this offer?', message: 'The farmer will no longer see it as pending.', confirmLabel: 'Withdraw offer', danger: true }))) return;
    try { await offersApi.update(o.id, 'withdrawn'); toast('Offer withdrawn.'); load(); }
    catch (e) { toast(`Could not withdraw the offer. ${e.message}`, 'error'); }
  };
  const track = async (o) => {
    try {
      const d = await deliveriesApi.byOffer(o.id);
      go(`/trip/${encodeURIComponent(d.id)}`);
    } catch (e) {
      if (e.status === 404) go(`/delivery/${encodeURIComponent(o.id)}`); // nothing chosen yet: pick pickup or delivery
      else toast(e.message, 'error');
    }
  };

  async function load() {
    body.replaceChildren(loading());
    try {
      const offers = await offersApi.mine();
      if (!offers.length) { body.replaceChildren(empty('You have not made any offers yet', 'Browse the marketplace and choose "Make an offer" or "Buy now" on a listing.', h('a', { class: 'btn btn-primary', href: '#/marketplace' }, 'Browse the marketplace'))); return; }
      body.replaceChildren(h('div', { class: 'card-list' }, ...offers.map((o) => {
        const canPay = o.status === 'accepted' && o.paymentStatus !== 'paid';
        return h('div', { class: 'card offer' },
          h('div', { class: 'row between' }, h('h3', null, h('a', { href: `#/listing/${encodeURIComponent(o.listingId)}`, style: { color: 'inherit', textDecoration: 'none' } }, o.listingTitle || 'Listing')), pill(o.paymentStatus === 'paid' ? 'paid' : o.status)),
          o.createdAt ? h('div', { class: 'muted small' }, `Sent ${formatDate(o.createdAt)}`) : null,
          o.offerPrice !== null ? h('div', { class: 'price' }, `Offer: ${money(o.offerPrice)}`) : null,
          o.message ? h('div', { class: 'quote' }, o.message) : null,
          o.status === 'declined' && o.declineReason ? h('div', { class: 'why' }, h('strong', null, 'Why the farmer declined'), o.declineReason) : null,
          o.status === 'pending' ? h('div', null, h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: () => withdraw(o) }, 'Withdraw')) : null,
          canPay ? h('div', null, h('a', { class: 'btn btn-primary btn-sm', href: `#/checkout/${encodeURIComponent(o.id)}` }, 'Pay now (demo checkout)')) : null,
          o.paymentStatus === 'paid' ? h('div', { class: 'row' }, h('a', { class: 'btn btn-outline btn-sm', href: `#/receipt/${encodeURIComponent(o.id)}` }, 'View slip'), h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: () => track(o) }, icon('truck', 16), 'Track delivery or pickup')) : null);
      })));
    } catch (e) { body.replaceChildren(errorBox(`Could not load your offers. ${e.message}`, load)); }
  }
  load();

  return { title: 'My offers', node: h('div', { class: 'page medium' }, h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'My offers'), h('p', null, 'Offers and purchases you have made.'))), body) };
}
