// Small DOM + UI helpers. Everything is built with createElement/textContent
// (never innerHTML with data), so user-supplied text can't inject markup.

const SVG_NS = 'http://www.w3.org/2000/svg';

export function h(tag, props, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k === 'value') el.value = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  append(el, children);
  return el;
}

function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

// Icons (24px, stroke style). Static strings only - safe for innerHTML.
const ICONS = {
  pin: '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.800 12 21 12 21z"/><circle cx="12" cy="9.500" r="2.500"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  store: '<path d="M4 9l1.500-5h13L20 9M4 9v11h16V9M4 9c0 1.700 1.300 3 3 3s3-1.300 3-3c0 1.700 1.300 3 3 3s3-1.300 3-3c0 1.700 1.300 3 3 3"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8L3 12z"/><circle cx="7.500" cy="8.500" r="1.200"/>',
  check: '<path d="M5 13l4 4L19 7"/>',
  truck: '<path d="M2 6h11v10H2zM13 9h5l3 3v4h-8"/><circle cx="6.500" cy="17.500" r="1.800"/><circle cx="17.500" cy="17.500" r="1.800"/>',
  walk: '<circle cx="13" cy="4.500" r="1.800"/><path d="M9 21l2-6-2-3 3-4 3 3 3 1M11 15l3 2 1 4M9 12l-3 1"/>',
  filter: '<path d="M4 6h16M7 12h10M10 18h4"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.500"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  paw: '<circle cx="6" cy="10" r="2"/><circle cx="10" cy="5.500" r="2"/><circle cx="15" cy="5.500" r="2"/><circle cx="19" cy="10" r="2"/><path d="M12 12c-3 0-5.500 3-5.500 5.500 0 2 2 2.500 3.500 2s1.500-.5 2-.5 .5.500 2 .5 3.500-.5 3.500-2C17.500 15 15 12 12 12z"/>',
  navigate: '<path d="M3 11l18-8-8 18-2-8-8-2z"/>',
};

export function icon(name, size = 22) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.8');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  svg.innerHTML = ICONS[name] || '';
  return svg;
}

export const spinner = () => h('span', { class: 'spin', role: 'status', 'aria-label': 'Loading' });
export const loading = (text = 'Loading...') => h('div', { class: 'loading' }, spinner(), text);

export function money(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 'R0';
  return 'R' + Math.round(v).toLocaleString('en-ZA').replace(/ /g, ' ');
}

export function priceParts(listing) {
  return { amount: money(listing.askingPrice), unit: listing.priceUnit === 'per_kg' ? '/kg' : '/head' };
}

export function formatDate(d) {
  if (!d) return '';
  const date = d instanceof Date ? d : new Date(d);
  if (isNaN(date)) return '';
  return date.toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

export function statusLabel(s) { return String(s || '').replace('_', ' '); }

// ---- toasts ---------------------------------------------------------
export function toast(message, kind = '') {
  const host = document.getElementById('toasts');
  const t = h('div', { class: `toast ${kind}`, role: 'status' }, message);
  host.append(t);
  setTimeout(() => t.remove(), kind === 'error' ? 6000 : 3500);
}

// ---- modals ---------------------------------------------------------
// openModal(build) -> { close, el }. `build(close)` returns the modal's
// children. Escape and a click on the backdrop close it.
const openClosers = new Set();
// Closes every open dialog (used on page navigation so none is left floating over the next page).
export function closeAllModals() { [...openClosers].forEach((c) => c()); }

export function openModal(build, { className = '', onClose } = {}) {
  const previouslyFocused = document.activeElement;
  const overlay = h('div', { class: 'overlay' });
  const modal = h('div', { class: `modal ${className}`, role: 'dialog', 'aria-modal': 'true' });
  let closed = false;
  const close = (result) => {
    if (closed) return;
    closed = true;
    openClosers.delete(close);
    document.removeEventListener('keydown', onKey);
    overlay.remove();
    if (previouslyFocused && previouslyFocused.focus) previouslyFocused.focus();
    if (onClose) onClose(result);
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  openClosers.add(close);
  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });
  append(modal, [build(close)]);
  overlay.append(modal);
  document.body.append(overlay);
  const first = modal.querySelector('input, select, textarea, button.btn-primary');
  if (first) first.focus();
  return { close, el: modal };
}

// Promise-based dialogs ---------------------------------------------------
export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    openModal((close) => [
      h('h2', null, title),
      message ? h('p', { class: 'muted' }, message) : null,
      h('div', { class: 'modal-actions' },
        h('button', { class: 'btn btn-outline', type: 'button', onclick: () => close(false) }, 'Cancel'),
        h('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, type: 'button', onclick: () => close(true) }, confirmLabel)),
    ], { onClose: (r) => resolve(r === true) });
  });
}

// Asks for one text/number value. Resolves with the string, or null if cancelled.
export function promptDialog({ title, message, label, initial = '', type = 'text', prefix, placeholder, confirmLabel = 'Confirm', validate, multiline = false }) {
  return new Promise((resolve) => {
    openModal((close) => {
      const input = multiline
        ? h('textarea', { class: 'textarea', placeholder, 'aria-label': label })
        : h('input', { class: 'input', type, value: initial, placeholder, 'aria-label': label, inputmode: type === 'number' ? 'decimal' : undefined, step: type === 'number' ? 'any' : undefined });
      if (multiline) input.value = initial;
      const err = h('div', { class: 'form-msg error', hidden: true });
      const submit = () => {
        const value = input.value.trim();
        const problem = validate ? validate(value) : null;
        if (problem) { err.textContent = problem; err.hidden = false; return; }
        close(value);
      };
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !multiline) { e.preventDefault(); submit(); } });
      return [
        h('h2', null, title),
        message ? h('p', { class: 'muted' }, message) : null,
        h('div', { class: 'field' }, label ? h('label', null, label) : null, prefix ? h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, h('b', null, prefix), input) : input),
        err,
        h('div', { class: 'modal-actions' },
          h('button', { class: 'btn btn-outline', type: 'button', onclick: () => close(null) }, 'Cancel'),
          h('button', { class: 'btn btn-primary', type: 'button', onclick: submit }, confirmLabel)),
      ];
    }, { onClose: (r) => resolve(typeof r === 'string' ? r : null) });
  });
}

// Disable a button + show a spinner while an async action runs.
export async function withBusy(button, fn) {
  const original = Array.from(button.childNodes);
  button.disabled = true;
  button.replaceChildren(spinner());
  try { return await fn(); }
  finally { button.disabled = false; button.replaceChildren(...original); }
}

export function field(label, input, hint) {
  const id = 'f' + Math.random().toString(36).slice(2, 8);
  input.id = id;
  return h('div', { class: 'field' }, h('label', { for: id }, label), input, hint ? h('div', { class: 'hint' }, hint) : null);
}

export function errorBox(message, retry) {
  return h('div', { class: 'error-box', role: 'alert' },
    h('div', null, message),
    retry ? h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: retry }, 'Try again') : null);
}

export function empty(title, text, action) {
  return h('div', { class: 'empty' }, h('h3', null, title), text ? h('p', null, text) : null, action || null);
}

export function backLink(href, label) {
  return h('a', { class: 'backlink', href }, icon('back', 16), label);
}

export function pill(status, text) {
  return h('span', { class: `pill ${status}` }, text || statusLabel(status));
}

export function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}
