// Auth state for the whole app (the web equivalent of AuthProvider).
import { http, session, toProfile } from './api.js';

export const auth = {
  status: 'unknown',  // unknown | authenticated | unauthenticated
  profile: null,
  get loggedIn() { return this.status === 'authenticated'; },
  get isFarmer() { return !!this.profile && this.profile.role === 'farmer'; },
  get userId() { return this.profile ? this.profile.id : null; },
};

const listeners = new Set();
export function onAuthChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit() { listeners.forEach((fn) => fn()); }

export async function bootstrap() {
  if (!session.access) { auth.status = 'unauthenticated'; emit(); return; }
  try {
    auth.profile = toProfile(await http.get('/api/auth/me'));
    auth.status = 'authenticated';
  } catch (e) {
    // Only drop the session when the server says it's invalid - a network
    // blip shouldn't log somebody out.
    if (e.status === 401 || e.status === 403) { session.clear(); auth.profile = null; auth.status = 'unauthenticated'; }
    else { auth.status = session.access ? 'authenticated' : 'unauthenticated'; }
  }
  emit();
}

export async function login(email, password) {
  const data = await http.post('/api/auth/login', { email, password }, { auth: false });
  session.save(data.accessToken, data.refreshToken);
  auth.profile = toProfile(data.profile);
  auth.status = 'authenticated';
  emit();
  return auth.profile;
}

export async function register({ fullName, email, phone, password }) {
  const data = await http.post('/api/auth/register', { fullName, email, phone, password }, { auth: false });
  if (data.accessToken && !data.requiresEmailConfirmation) {
    session.save(data.accessToken, data.refreshToken);
    auth.profile = toProfile(data.profile);
    auth.status = 'authenticated';
    emit();
  }
  return { message: data.message, requiresEmailConfirmation: !!data.requiresEmailConfirmation, signedIn: auth.loggedIn };
}

export async function logout() {
  try { if (session.access) await http.post('/api/auth/logout', {}); } catch { /* still log out locally */ }
  session.clear();
  auth.profile = null;
  auth.status = 'unauthenticated';
  emit();
}

export function expireSession() {
  session.clear();
  auth.profile = null;
  auth.status = 'unauthenticated';
  emit();
}

export async function updateProfile({ fullName, phone, location }) {
  auth.profile = toProfile(await http.put('/api/auth/me', { fullName, phone, location }));
  emit();
  return auth.profile;
}

export async function changePassword(currentPassword, newPassword) {
  await http.put('/api/auth/password', { currentPassword, newPassword });
}

export const homePath = () => (auth.isFarmer ? '/dashboard' : '/marketplace');

// ---- password reset + email-link handling ------------------------------
let recoveryToken = null;
export const getRecoveryToken = () => recoveryToken;
export const setRecoveryToken = (t) => { recoveryToken = t; };

export async function forgotPassword(email) {
  return http.post('/api/auth/forgot-password', { email }, { auth: false });
}

export async function resetPassword(newPassword) {
  if (!recoveryToken) throw new Error('This reset link is missing or has expired. Request a new one.');
  const data = await http.post('/api/auth/reset-password', { newPassword }, { auth: false, token: recoveryToken });
  recoveryToken = null;
  return data;
}

// Links in Supabase emails open the site as  /#access_token=...&type=signup|recovery
// (or /#error=...). Real routes always start with "/", so anything else is an auth fragment.
export function consumeAuthFragment() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw || raw.startsWith('/')) return null;
  if (!raw.includes('access_token=') && !raw.includes('error=')) return null;
  const p = new URLSearchParams(raw);
  return { type: p.get('type'), access: p.get('access_token'), refresh: p.get('refresh_token'), error: p.get('error_description') || p.get('error') };
}
