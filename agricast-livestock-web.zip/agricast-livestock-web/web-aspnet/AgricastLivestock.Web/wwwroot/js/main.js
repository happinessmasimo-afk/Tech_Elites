import { h } from './ui.js';
import { auth, bootstrap, onAuthChange, logout, expireSession, homePath, consumeAuthFragment, setRecoveryToken } from './auth.js';
import { session } from './api.js';
import { startNotifier } from './notifications.js';
import { route, startRouter, go, onNavigate, currentPath } from './router.js';
import { toast } from './ui.js';

import { landingPage } from './pages/landing.js';
import { loginPage, registerPage } from './pages/auth.js';
import { forgotPasswordPage, resetPasswordPage } from './pages/password.js';
import { receiptPage } from './pages/receipt.js';
import { marketplacePage } from './pages/marketplace.js';
import { listingPage } from './pages/listing.js';
import { createListingPage } from './pages/createListing.js';
import { myListingsPage } from './pages/myListings.js';
import { receivedOffersPage } from './pages/receivedOffers.js';
import { myOffersPage } from './pages/myOffers.js';
import { checkoutPage } from './pages/checkout.js';
import { deliveryMethodPage } from './pages/deliveryMethod.js';
import { tripPage } from './pages/trip.js';
import { dashboardPage } from './pages/dashboard.js';
import { financePage } from './pages/finance.js';
import { profilePage, editProfilePage, changePasswordPage } from './pages/profile.js';

route('/', landingPage);
route('/login', loginPage, { guestOnly: true });
route('/register', registerPage, { guestOnly: true });
route('/forgot-password', forgotPasswordPage, { guestOnly: true });
route('/reset-password', resetPasswordPage);
route('/receipt/:offerId', receiptPage, { auth: true });
route('/marketplace', marketplacePage);
route('/listing/:id', listingPage);
route('/new-listing', createListingPage, { auth: true, role: 'farmer' });
route('/my-listings', myListingsPage, { auth: true, role: 'farmer' });
route('/offers-received', receivedOffersPage, { auth: true, role: 'farmer' });
route('/dashboard', dashboardPage, { auth: true, role: 'farmer' });
route('/finance', financePage, { auth: true, role: 'farmer' });
route('/my-offers', myOffersPage, { auth: true, role: 'buyer' });
route('/checkout/:offerId', checkoutPage, { auth: true });
route('/delivery/:offerId', deliveryMethodPage, { auth: true });
route('/trip/:id', tripPage, { auth: true });
route('/profile', profilePage, { auth: true });
route('/profile/edit', editProfilePage, { auth: true });
route('/profile/password', changePasswordPage, { auth: true });

// ---- top bar ----------------------------------------------------------
const topbar = document.getElementById('topbar');

function navLink(path, text, current) {
  const active = current === path || (path !== '/' && current.startsWith(path + '/'));
  return h('a', { href: '#' + path, 'aria-current': active ? 'page' : null }, text);
}

function renderTopbar() {
  const current = currentPath();
  const links = [navLink('/marketplace', 'Marketplace', current)];
  if (auth.loggedIn && auth.isFarmer) {
    links.push(navLink('/dashboard', 'Dashboard', current), navLink('/my-listings', 'My listings', current),
      navLink('/offers-received', 'Offers received', current), navLink('/finance', 'Finance', current));
  } else if (auth.loggedIn) {
    links.push(navLink('/my-offers', 'My offers', current));
  }
  if (auth.loggedIn) {
    links.push(navLink('/profile', 'Profile', current));
  } else if (auth.status !== 'unknown') {
    links.push(navLink('/login', 'Log in', current), navLink('/register', 'Register', current));
  }
  topbar.replaceChildren(h('div', { class: 'topbar-inner' },
    h('a', { class: 'brand', href: '#/', 'aria-label': 'Agricast Livestock home' }, h('img', { src: '/img/icon.png', alt: '' }), h('span', null, 'Agricast Livestock')),
    h('nav', { class: 'nav', 'aria-label': 'Main' }, links)));
}

onAuthChange(renderTopbar);
onNavigate(renderTopbar);

window.addEventListener('agricast:session-expired', () => {
  expireSession();
  toast('Your session expired. Please log in again.', 'error');
  go('/login');
});

// Links in confirmation / reset emails arrive as  /#access_token=...&type=signup|recovery
async function handleEmailLink() {
  const frag = consumeAuthFragment();
  if (!frag) return;
  history.replaceState(null, '', location.pathname + location.search + '#/');
  if (frag.error) { toast(`That email link did not work: ${frag.error.replace(/\+/g, ' ')}. Request a new one.`, 'error'); location.hash = '#/login'; return; }
  if (frag.type === 'recovery' && frag.access) { setRecoveryToken(frag.access); location.hash = '#/reset-password'; return; }
  if (frag.access) {
    session.save(frag.access, frag.refresh || '');
    await bootstrap();
    toast('Email confirmed. Welcome to Agricast!', 'ok');
    location.hash = '#' + homePath();
  }
}

startNotifier();
(async function init() {
  renderTopbar();
  await handleEmailLink();
  if (auth.status === 'unknown') await bootstrap();
  await startRouter();
})();

export { logout, homePath };
