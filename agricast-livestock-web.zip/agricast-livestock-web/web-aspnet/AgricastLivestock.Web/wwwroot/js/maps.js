// Maps: Leaflet (loaded on demand from a CDN) + Mapbox raster tiles and
// geocoding - the same Mapbox public token and tile style the Flutter app uses.
import { MAPBOX_TOKEN } from './api.js';
import { h, icon, openModal, debounce, toast } from './ui.js';

const LEAFLET_JS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
const LEAFLET_CSS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
const SA_CENTER = [-28.5, 24.7];

let leafletPromise = null;
export function loadLeaflet() {
  if (window.L) return Promise.resolve(true);
  if (!leafletPromise) {
    leafletPromise = new Promise((resolve) => {
      const css = document.createElement('link');
      css.rel = 'stylesheet'; css.href = LEAFLET_CSS;
      document.head.append(css);
      const s = document.createElement('script');
      s.src = LEAFLET_JS;
      s.onload = () => resolve(!!window.L);
      s.onerror = () => { leafletPromise = null; resolve(false); };
      document.head.append(s);
    });
  }
  return leafletPromise;
}

const PIN_SVG = '<svg viewBox="0 0 36 36"><path d="M18 34s11-9.500 11-18A11 11 0 0 0 7 16c0 8.500 11 18 11 18z" fill="#159947" stroke="#fff" stroke-width="2"/><circle cx="18" cy="16" r="4" fill="#fff"/></svg>';
const FLAG_SVG = '<svg viewBox="0 0 36 36"><path d="M10 33V4" stroke="#12813c" stroke-width="3" stroke-linecap="round"/><path d="M10 5h19l-5 7 5 7H10z" fill="#12813c" stroke="#fff" stroke-width="1.500" stroke-linejoin="round"/></svg>';
const MOVER_SVG = '<svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="14" fill="#159947" stroke="#fff" stroke-width="3"/><path d="M18 9l6 16-6-3.500L12 25z" fill="#fff"/></svg>';

function markerIcon(L, kind) {
  if (kind === 'flag') return L.divIcon({ className: 'pin-wrap', html: `<div class="pin">${FLAG_SVG}</div>`, iconSize: [36, 36], iconAnchor: [10, 33] });
  if (kind === 'mover') return L.divIcon({ className: 'pin-wrap', html: `<div class="pin">${MOVER_SVG}</div>`, iconSize: [36, 36], iconAnchor: [18, 18] });
  return L.divIcon({ className: 'pin-wrap', html: `<div class="pin">${PIN_SVG}</div>`, iconSize: [36, 36], iconAnchor: [18, 34] });
}

function addTiles(L, map) {
  if (MAPBOX_TOKEN) {
    L.tileLayer(`https://api.mapbox.com/styles/v1/mapbox/streets-v12/tiles/256/{z}/{x}/{y}@2x?access_token=${MAPBOX_TOKEN}`, {
      maxZoom: 19, attribution: '&copy; <a href="https://www.mapbox.com/">Mapbox</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);
  } else {
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
  }
}

// Mounts a map into `box`. markers: [{lat, lng, kind: 'pin'|'flag'|'mover', label}]
export async function mountMap(box, { markers = [], center = null, zoom = 14 } = {}) {
  const ok = await loadLeaflet();
  if (!ok) {
    box.append(h('div', { class: 'map-note' }, 'The map could not be loaded. Check your internet connection and reload the page.'));
    return { ok: false, setMarkers() {}, setRoute() {}, destroy() {}, map: null };
  }
  const L = window.L;
  const map = L.map(box, { zoomControl: true }).setView(center || SA_CENTER, center ? zoom : 5);
  addTiles(L, map);
  const layer = L.layerGroup().addTo(map);
  const routeLayer = L.layerGroup().addTo(map);
  const api = {
    ok: true, map, L,
    setMarkers(list, { fit = false } = {}) {
      layer.clearLayers();
      const pts = [];
      for (const m of list) {
        if (m.lat == null || m.lng == null) continue;
        L.marker([m.lat, m.lng], { icon: markerIcon(L, m.kind), title: m.label || '', keyboard: false }).addTo(layer);
        pts.push([m.lat, m.lng]);
      }
      if (fit && pts.length) {
        if (pts.length === 1) map.setView(pts[0], zoom);
        else map.fitBounds(pts, { padding: [60, 60], maxZoom: 15 });
      }
    },
    // Draws a road route (list of [lat, lng]) like a navigator: white casing + green line.
    setRoute(coords, { fit = false } = {}) {
      routeLayer.clearLayers();
      if (!coords || coords.length < 2) return;
      L.polyline(coords, { color: '#ffffff', weight: 9, opacity: 0.95, lineCap: 'round', lineJoin: 'round' }).addTo(routeLayer);
      L.polyline(coords, { color: '#159947', weight: 5, opacity: 1, lineCap: 'round', lineJoin: 'round' }).addTo(routeLayer);
      if (fit) map.fitBounds(coords, { padding: [60, 60], maxZoom: 16 });
    },
    destroy() { try { map.remove(); } catch { /* already gone */ } },
  };
  api.setMarkers(markers, { fit: true });
  setTimeout(() => map.invalidateSize(), 60);
  return api;
}

// ---- driving directions (Mapbox) -----------------------------------------
// Returns { coords: [[lat, lng], ...], distanceKm, minutes } or null if Mapbox can't be reached.
export async function fetchRoute(from, to) {
  if (!MAPBOX_TOKEN || from == null || to == null) return null;
  const url = `https://api.mapbox.com/directions/v5/mapbox/driving/${from.lng},${from.lat};${to.lng},${to.lat}` +
    `?geometries=geojson&overview=full&access_token=${MAPBOX_TOKEN}`;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    const r = data.routes && data.routes[0];
    if (!r) return null;
    return { coords: r.geometry.coordinates.map(([lng, lat]) => [lat, lng]), distanceKm: r.distance / 1000, minutes: Math.max(1, Math.ceil(r.duration / 60)) };
  } catch { return null; }
}

const haversineKm = (a, b) => {
  const R = 6371, rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
};

// Keeps the drawn route and ETA fresh without hammering Mapbox: it only refetches
// when the start moved ~150 m, the destination changed, or 30 s passed.
export function createRouteTracker(onResult) {
  let last = null; let lastAt = 0; let busy = false;
  return {
    async update(from, to) {
      if (!from || !to) { if (last) { last = null; onResult(null); } return; }
      const key = { from, to };
      const moved = !last || haversineKm(last.from, from) > 0.15 || haversineKm(last.to, to) > 0.01;
      if (busy || (!moved && Date.now() - lastAt < 30000)) return;
      busy = true;
      try {
        const route = await fetchRoute(from, to);
        if (route) { last = key; lastAt = Date.now(); onResult(route); }
      } finally { busy = false; }
    },
    reset() { last = null; lastAt = 0; },
  };
}

export const navigationUrl = (from, to) =>
  `https://www.google.com/maps/dir/?api=1${from ? `&origin=${from.lat},${from.lng}` : ''}&destination=${to.lat},${to.lng}&travelmode=driving`;

// ---- geocoding (Mapbox) ---------------------------------------------------
export async function searchPlaces(query) {
  const q = query.trim();
  if (q.length < 3) return [];
  const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(q)}.json?access_token=${MAPBOX_TOKEN}&autocomplete=true&limit=5`;
  let res;
  try { res = await fetch(url); } catch { throw new Error('Could not reach Mapbox. Check your internet connection.'); }
  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try { const b = await res.json(); if (b.message) detail = b.message; } catch { /* not json */ }
    throw new Error(`Mapbox search failed (${detail})`);
  }
  const data = await res.json();
  return (data.features || []).map((f) => ({ label: f.place_name, lng: f.center[0], lat: f.center[1] }));
}

const reverseCache = new Map();
export async function reverseGeocode(lat, lng) {
  const key = `${lat.toFixed(5)},${lng.toFixed(5)}`;
  if (reverseCache.has(key)) return reverseCache.get(key);
  try {
    const res = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${MAPBOX_TOKEN}&limit=1`);
    if (!res.ok) return null;
    const data = await res.json();
    const name = data.features && data.features[0] ? data.features[0].place_name : null;
    if (name) reverseCache.set(key, name);
    return name;
  } catch { return null; }
}

export const coordsText = (lat, lng) => `${lat.toFixed(5)}, ${lng.toFixed(5)}`;

// A <span> that shows coordinates immediately, then swaps in a place name.
export function addressText(lat, lng, className = '') {
  const el = h('span', { class: className }, coordsText(lat, lng));
  reverseGeocode(lat, lng).then((name) => { if (name) el.textContent = name; });
  return el;
}

// ---- location picker ------------------------------------------------------
// Opens a full dialog: search a place, click the map, or use the device
// location. Resolves {lat, lng, label} or null if cancelled.
export function pickLocation({ title = 'Pin the location', initial = null, confirmLabel = 'Use this location' } = {}) {
  return new Promise((resolve) => {
    let picker = null;
    let selected = initial ? { lat: initial.lat, lng: initial.lng, label: initial.label || null } : null;

    openModal((close) => {
      const label = h('div', { class: 'grow' });
      const confirm = h('button', { class: 'btn btn-primary', type: 'button', disabled: !selected, onclick: () => close(selected) }, confirmLabel);
      const mapBox = h('div', { class: 'map-box full' });
      const manual = h('div', { class: 'row', hidden: true, style: { padding: '16px 20px' } });
      const err = h('div', { class: 'form-msg error', hidden: true });
      const suggest = h('div', { class: 'suggest', hidden: true });
      const search = h('input', { class: 'input', type: 'search', placeholder: 'Search for a farm, town or address', 'aria-label': 'Search for a place', autocomplete: 'off' });

      const refreshLabel = () => {
        confirm.disabled = !selected;
        if (!selected) label.replaceChildren(h('span', { class: 'muted' }, 'Click the map, search, or use your location.'));
        else label.replaceChildren(h('b', null, selected.label || coordsText(selected.lat, selected.lng)));
      };

      const choose = async (lat, lng, name, { moveMap = true } = {}) => {
        selected = { lat, lng, label: name || null };
        refreshLabel();
        if (picker && picker.ok) {
          picker.setMarkers([{ lat, lng, kind: 'pin' }]);
          if (moveMap) picker.map.setView([lat, lng], Math.max(picker.map.getZoom(), 14));
        }
        if (!name) {
          const found = await reverseGeocode(lat, lng);
          if (selected && selected.lat === lat && selected.lng === lng && found) { selected.label = found; refreshLabel(); }
        }
      };

      const runSearch = debounce(async () => {
        err.hidden = true;
        try {
          const results = await searchPlaces(search.value);
          suggest.replaceChildren(...results.map((r) => h('button', { type: 'button', onclick: () => { suggest.hidden = true; search.value = r.label; choose(r.lat, r.lng, r.label); } }, r.label)));
          suggest.hidden = results.length === 0;
        } catch (e) { err.textContent = e.message; err.hidden = false; suggest.hidden = true; }
      }, 350);
      search.addEventListener('input', runSearch);

      const useMine = h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: () => {
        if (!navigator.geolocation) { err.textContent = 'This browser cannot share your location.'; err.hidden = false; return; }
        navigator.geolocation.getCurrentPosition(
          (pos) => { err.hidden = true; choose(pos.coords.latitude, pos.coords.longitude, null); },
          () => { err.textContent = 'Could not read your location. Allow location access in the browser, or search for the place instead.'; err.hidden = false; },
          { enableHighAccuracy: true, timeout: 15000 });
      } }, icon('navigate', 16), 'Use my location');

      // Manual fallback only appears if the map library can't load.
      const lat = h('input', { class: 'input', type: 'number', step: 'any', placeholder: 'Latitude', 'aria-label': 'Latitude' });
      const lng = h('input', { class: 'input', type: 'number', step: 'any', placeholder: 'Longitude', 'aria-label': 'Longitude' });
      manual.append(lat, lng, h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: () => {
        const a = parseFloat(lat.value), b = parseFloat(lng.value);
        if (Number.isFinite(a) && Number.isFinite(b) && Math.abs(a) <= 90 && Math.abs(b) <= 180) choose(a, b, null, { moveMap: false });
      } }, 'Set'));

      refreshLabel();
      mountMap(mapBox, { center: selected ? [selected.lat, selected.lng] : null, zoom: 14, markers: selected ? [{ lat: selected.lat, lng: selected.lng, kind: 'pin' }] : [] }).then((m) => {
        picker = m;
        if (!m.ok) { manual.hidden = false; return; }
        m.map.on('click', (e) => choose(e.latlng.lat, e.latlng.lng, null, { moveMap: false }));
      });

      return [
        h('div', { class: 'picker-top' },
          h('div', { class: 'modal-head' }, h('h2', null, title), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Close', onclick: () => close(null) }, icon('x', 20))),
          h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, h('div', { class: 'grow' }, search), useMine),
          err, suggest),
        h('div', { class: 'picker-map' }, mapBox, manual),
        h('div', { class: 'picker-bottom' }, label,
          h('div', { class: 'row' }, h('button', { class: 'btn btn-outline', type: 'button', onclick: () => close(null) }, 'Cancel'), confirm)),
      ];
    }, {
      className: 'map',
      onClose: (result) => { if (picker) picker.destroy(); resolve(result && result.lat !== undefined ? result : null); },
    });
  });
}
