# Email setup (Resend + Supabase)

Three kinds of email are covered:

| Email | Sent by | Needs |
|---|---|---|
| Confirm your account | Supabase Auth, delivered through Resend SMTP | Steps 1 to 4 below |
| Reset your password | Supabase Auth, delivered through Resend SMTP | Steps 1 to 4 below |
| Purchase slip | The API, straight through the Resend API | Only the key in `appsettings.Development.json` (already set) |

## 0. Rotate your key first
The Resend key was pasted into a chat. In Resend go to **API Keys**, create a new one, delete the old one, and put the new one in
`backend-aspnet/AgricastLivestock.Api/appsettings.Development.json` under `Resend:ApiKey`. That file is git-ignored. Never put the key in the web front end.

## 1. Sender address
Resend's test sender `onboarding@resend.dev` only delivers to the email you registered Resend with.
To email real customers: Resend, **Domains**, add your domain, add the DNS records, then set `Resend:From` (for example `Agricast <no-reply@yourdomain.com>`).

## 2. Supabase: URLs
Dashboard, **Authentication, URL Configuration**
- Site URL: `http://localhost:5080` (use your real address when you deploy)
- Redirect URLs: `http://localhost:5080/**`

## 3. Supabase: send auth emails through Resend
Dashboard, **Authentication, Emails, SMTP Settings**, turn on custom SMTP:
- Host `smtp.resend.com`, Port `465`
- Username `resend`
- Password: your Resend API key
- Sender email: same address as `Resend:From`, sender name `Agricast Livestock`

Also make sure **Authentication, Providers, Email, Confirm email** is ON.

## 4. Supabase: paste the templates
**Authentication, Emails, Templates**
- *Confirm signup*: subject `Confirm your Agricast account`, body = `supabase/email-templates/confirm-signup.html`
- *Reset password*: subject `Reset your Agricast password`, body = `supabase/email-templates/reset-password.html`

## How it flows
1. Register, the API asks Supabase to send the confirm email, the link opens `http://localhost:5080/#access_token=...`, the site signs you in.
2. Forgot password, enter email, the link opens the site on the "Choose a new password" page.
3. Pay, the slip is emailed to the buyer and is always viewable at **View slip** for both buyer and farmer.

If an email never arrives, check Resend, **Logs**, and the spam folder. Slip emails never block a payment if sending fails.
