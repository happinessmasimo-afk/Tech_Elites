# Agricast Livestock: web app

A browser version of the Agricast Livestock Flutter app, on the same stack and the **same backend**.

```
Browser (this web app)  ->  ASP.NET Core API (backend-aspnet, unchanged)  ->  Supabase (Auth + Postgres + Storage)
```

| Folder | What it is |
|---|---|
| `backend-aspnet/AgricastLivestock.Api` | Your existing API, copied as-is (port **5050**). Supabase URL and anon key are already in its `appsettings.json`. |
| `web-aspnet/AgricastLivestock.Web` | **New.** ASP.NET Core project that serves the website (port **5080**). The pages live in `wwwroot/`. |
| `supabase/migrations` | Your existing migrations. Skip this if the database is already set up for the mobile app. |

## Run it in VS Code

1. Install the **.NET 9 SDK** (or newer) and the **C# Dev Kit** extension (VS Code will offer it).
2. `File > Open Folder...` and choose this folder (`agricast-livestock-web`).
3. Press **F5** and pick **"Agricast: API + Web (press F5)"**. Both projects start and the browser opens at <http://localhost:5080>.

No VS Code debugger? Run `./start.sh` (Mac/Linux) or double-click `start.bat` (Windows), or in two terminals:

```bash
dotnet run --project backend-aspnet/AgricastLivestock.Api   # http://localhost:5050
dotnet run --project web-aspnet/AgricastLivestock.Web       # http://localhost:5080
```

## Settings

- **API address and Mapbox token for the website:** `web-aspnet/AgricastLivestock.Web/appsettings.json` (`Api:BaseUrl`, `Mapbox:Token`). The website reads them from `/app-config.js`, so there is no JavaScript to edit.
- **Supabase keys:** `backend-aspnet/AgricastLivestock.Api/appsettings.json`, as before. The website never talks to Supabase directly.
- To deploy, host the API somewhere public, set `Api:BaseUrl` to its https address, and host the Web project. The API already allows any origin (CORS).

## Email, password reset and slips
See [EMAIL-SETUP.md](EMAIL-SETUP.md) for the Resend and Supabase steps and the email templates in `supabase/email-templates/`.

## Roles

Same rules as the mobile app. Everyone who registers is a **buyer**. The one farmer account is promoted in Supabase (SQL Editor):

```sql
update public.profiles set role = 'farmer' where email = 'YOUR_FARMER_EMAIL_HERE';
```

Farmers land on the Dashboard and get My listings, Offers received and Finance. Buyers get My offers.

## What's in the web app (everything the Flutter app does)

- Landing, log in, register (including the "confirm your email" case), log out, silent token refresh
- Marketplace for guests too: search, sort, filters (species, sex, breed, location, price, age, weight)
- Listing page: photo gallery, details, map, **Buy now**, **Make an offer**
- Farmer: dashboard (stats, live deliveries to-do with new-delivery alert), new listing (multi-photo upload, map pin with place search), my listings (mark sold, withdraw), offers received (accept, decline with a reason), finance
- Buyer: my offers (withdraw, pay, track)
- Demo checkout (summary, card, processing, success) that marks the offer paid and the listing sold
- Pickup or delivery choice, with live trip tracking in both directions. The traveller shares the browser's GPS position and the other side watches distance and ETA update. Distance and ETA come from the API's Mapbox call, as before.
- Profile, edit profile, change password

## Good to know

- Maps use Leaflet from a CDN plus your Mapbox tiles, so the page needs internet access. If the map can't load, the location picker falls back to place search and manual coordinates.
- Browsers only share GPS on `localhost` or `https`, so live trips work locally and on a deployed https site.
- Sessions are kept in the browser's `localStorage`.
