import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../services/auth_service.dart';
import '../widgets/app_text_field.dart';
import '../widgets/primary_button.dart';

/// Change your own password. This is also where a farmer replaces the
/// starting password the company gave them: enter that one as the current
/// password, then choose your own.
class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _current = TextEditingController();
  final _new = TextEditingController();
  final _confirm = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _save() async {
    if (_current.text.isEmpty) {
      setState(() => _error = 'Enter your current password.');
      return;
    }
    if (_new.text.length < 6) {
      setState(() => _error = 'New password must be at least 6 characters.');
      return;
    }
    if (_new.text != _confirm.text) {
      setState(() => _error = "The new passwords don't match.");
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await AuthService().changePassword(currentPassword: _current.text, newPassword: _new.text);
    if (!mounted) return;

    if (result.success) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password changed.')));
      Navigator.of(context).pop();
    } else {
      setState(() {
        _loading = false;
        _error = result.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Change password')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Use the password you were given (or your current one), then choose a new one.',
                style: AppFonts.body(color: AppColors.muted, size: 13),
              ),
              const SizedBox(height: 18),
              AppTextField(controller: _current, label: 'Current password', obscure: true),
              AppTextField(controller: _new, label: 'New password (min 6 characters)', obscure: true),
              AppTextField(controller: _confirm, label: 'Confirm new password', obscure: true),
              if (_error != null) ...[
                Text(_error!, style: AppFonts.bodyMedium(color: AppColors.danger, size: 13)),
                const SizedBox(height: 8),
              ],
              const SizedBox(height: 8),
              PrimaryButton(label: 'Change password', onPressed: _save, loading: _loading),
            ],
          ),
        ),
      ),
    );
  }
}
