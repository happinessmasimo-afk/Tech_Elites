import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../models/listing.dart';
import 'primary_button.dart';

/// Everything a buyer can narrow the marketplace by. Any field left null
/// means "don't filter on this". Applied on-device against the listings
/// already loaded, so changing a filter is instant.
class ListingFilter {
  String? species;
  String? sex; // male | female | mixed
  String breedQuery;
  String locationQuery;
  double? minPrice;
  double? maxPrice;
  int? minAgeMonths;
  int? maxAgeMonths;
  double? minWeightKg;
  double? maxWeightKg;

  ListingFilter({
    this.species,
    this.sex,
    this.breedQuery = '',
    this.locationQuery = '',
    this.minPrice,
    this.maxPrice,
    this.minAgeMonths,
    this.maxAgeMonths,
    this.minWeightKg,
    this.maxWeightKg,
  });

  ListingFilter copy() => ListingFilter(
        species: species,
        sex: sex,
        breedQuery: breedQuery,
        locationQuery: locationQuery,
        minPrice: minPrice,
        maxPrice: maxPrice,
        minAgeMonths: minAgeMonths,
        maxAgeMonths: maxAgeMonths,
        minWeightKg: minWeightKg,
        maxWeightKg: maxWeightKg,
      );

  /// How many separate filters are switched on (shown as a badge).
  int get activeCount => [
        species != null,
        sex != null,
        breedQuery.trim().isNotEmpty,
        locationQuery.trim().isNotEmpty,
        minPrice != null || maxPrice != null,
        minAgeMonths != null || maxAgeMonths != null,
        minWeightKg != null || maxWeightKg != null,
      ].where((on) => on).length;

  bool get isActive => activeCount > 0;

  bool matches(Listing l) {
    if (species != null && l.species.toLowerCase() != species!.toLowerCase()) return false;
    if (sex != null && (l.sex ?? '').toLowerCase() != sex) return false;
    if (breedQuery.trim().isNotEmpty && !(l.breed ?? '').toLowerCase().contains(breedQuery.trim().toLowerCase())) {
      return false;
    }
    if (locationQuery.trim().isNotEmpty && !(l.location ?? '').toLowerCase().contains(locationQuery.trim().toLowerCase())) {
      return false;
    }
    if (minPrice != null && l.askingPrice < minPrice!) return false;
    if (maxPrice != null && l.askingPrice > maxPrice!) return false;

    // For age/weight: a listing that doesn't state the value can't be
    // proven to fit a range, so it's left out once that filter is on.
    if (minAgeMonths != null || maxAgeMonths != null) {
      final age = l.ageMonths;
      if (age == null) return false;
      if (minAgeMonths != null && age < minAgeMonths!) return false;
      if (maxAgeMonths != null && age > maxAgeMonths!) return false;
    }
    if (minWeightKg != null || maxWeightKg != null) {
      final w = l.weightKg;
      if (w == null) return false;
      if (minWeightKg != null && w < minWeightKg!) return false;
      if (maxWeightKg != null && w > maxWeightKg!) return false;
    }
    return true;
  }
}

/// Opens the filter sheet. Returns the new filter when the buyer taps
/// Apply or Reset, or null if they dismissed it.
Future<ListingFilter?> showListingFilterSheet(
  BuildContext context, {
  required ListingFilter current,
  required List<String> speciesOptions,
}) {
  return showModalBottomSheet<ListingFilter>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.background,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (ctx) => _FilterSheet(current: current, speciesOptions: speciesOptions),
  );
}

class _FilterSheet extends StatefulWidget {
  final ListingFilter current;
  final List<String> speciesOptions;
  const _FilterSheet({required this.current, required this.speciesOptions});

  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  late ListingFilter _f;
  late final TextEditingController _breed;
  late final TextEditingController _location;
  late final TextEditingController _minPrice;
  late final TextEditingController _maxPrice;
  late final TextEditingController _minAge;
  late final TextEditingController _maxAge;
  late final TextEditingController _minWeight;
  late final TextEditingController _maxWeight;

  static String _n(num? v) => v == null ? '' : (v % 1 == 0 ? v.toInt().toString() : v.toString());

  @override
  void initState() {
    super.initState();
    _f = widget.current.copy();
    _breed = TextEditingController(text: _f.breedQuery);
    _location = TextEditingController(text: _f.locationQuery);
    _minPrice = TextEditingController(text: _n(_f.minPrice));
    _maxPrice = TextEditingController(text: _n(_f.maxPrice));
    _minAge = TextEditingController(text: _n(_f.minAgeMonths));
    _maxAge = TextEditingController(text: _n(_f.maxAgeMonths));
    _minWeight = TextEditingController(text: _n(_f.minWeightKg));
    _maxWeight = TextEditingController(text: _n(_f.maxWeightKg));
  }

  ListingFilter _collect() {
    return ListingFilter(
      species: _f.species,
      sex: _f.sex,
      breedQuery: _breed.text,
      locationQuery: _location.text,
      minPrice: double.tryParse(_minPrice.text.trim()),
      maxPrice: double.tryParse(_maxPrice.text.trim()),
      minAgeMonths: int.tryParse(_minAge.text.trim()),
      maxAgeMonths: int.tryParse(_maxAge.text.trim()),
      minWeightKg: double.tryParse(_minWeight.text.trim()),
      maxWeightKg: double.tryParse(_maxWeight.text.trim()),
    );
  }

  Widget _rangeRow(String label, TextEditingController min, TextEditingController max, {String? suffix}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: AppFonts.bodyMedium(color: AppColors.muted, size: 13)),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: min,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(hintText: 'Min', suffixText: suffix),
                ),
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 10), child: Text('to')),
              Expanded(
                child: TextField(
                  controller: max,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(hintText: 'Max', suffixText: suffix),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text('Filter listings', style: AppFonts.heading(size: 20, color: AppColors.text))),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(ListingFilter()),
                    child: const Text('Reset'),
                  ),
                ],
              ),
              const SizedBox(height: 8),

              Text('Species', style: AppFonts.bodyMedium(color: AppColors.muted, size: 13)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  ChoiceChip(
                    label: const Text('Any'),
                    selected: _f.species == null,
                    onSelected: (_) => setState(() => _f.species = null),
                  ),
                  for (final s in widget.speciesOptions)
                    ChoiceChip(
                      label: Text(s),
                      selected: _f.species?.toLowerCase() == s.toLowerCase(),
                      onSelected: (_) => setState(() => _f.species = s),
                    ),
                ],
              ),
              const SizedBox(height: 14),

              Text('Sex', style: AppFonts.bodyMedium(color: AppColors.muted, size: 13)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                children: [
                  for (final option in const [null, 'male', 'female', 'mixed'])
                    ChoiceChip(
                      label: Text(option == null ? 'Any' : option[0].toUpperCase() + option.substring(1)),
                      selected: _f.sex == option,
                      onSelected: (_) => setState(() => _f.sex = option),
                    ),
                ],
              ),
              const SizedBox(height: 14),

              _rangeRow('Price (R)', _minPrice, _maxPrice),
              _rangeRow('Age', _minAge, _maxAge, suffix: 'months'),
              _rangeRow('Weight', _minWeight, _maxWeight, suffix: 'kg'),

              Text('Breed', style: AppFonts.bodyMedium(color: AppColors.muted, size: 13)),
              const SizedBox(height: 6),
              TextField(controller: _breed, decoration: const InputDecoration(hintText: 'e.g. Bonsmara')),
              const SizedBox(height: 14),

              Text('Location', style: AppFonts.bodyMedium(color: AppColors.muted, size: 13)),
              const SizedBox(height: 6),
              TextField(controller: _location, decoration: const InputDecoration(hintText: 'e.g. Bloemfontein')),
              const SizedBox(height: 20),

              PrimaryButton(label: 'Show results', onPressed: () => Navigator.of(context).pop(_collect())),
            ],
          ),
        ),
      ),
    );
  }
}
