#!/bin/bash
# ---------------------------------------------------------------------------
# Run this ONE command every time you download a fresh copy of the app:
#
#     bash setup_ios.sh
#
# (from inside the mobile-flutter folder). It does the whole routine:
#   1. creates the ios/android folders if they're missing
#   2. runs flutter pub get
#   3. puts the location + photo permissions back into ios/Runner/Info.plist
#      -- this is the step that gets wiped every time the ios folder is
#      regenerated, which is why the location picker "never works"
#   4. checks the permission is really there, and tells you if it isn't
# ---------------------------------------------------------------------------

cd "$(dirname "$0")" || exit 1

echo ""
echo "1/4  Checking the iOS and Android project folders..."
if [ ! -d "ios" ] || [ ! -d "android" ]; then
  flutter create --project-name agricast_livestock_lite . || { echo "ERROR: flutter create failed."; exit 1; }
else
  echo "     already there"
fi

echo ""
echo "2/4  Installing packages (flutter pub get)..."
flutter pub get || { echo "ERROR: flutter pub get failed."; exit 1; }

echo ""
echo "3/4  Adding the iOS permissions..."
PLIST="ios/Runner/Info.plist"
if [ ! -f "$PLIST" ]; then
  echo "ERROR: $PLIST does not exist, so the permission can't be added."
  echo "       Make sure you ran this from inside the mobile-flutter folder."
  exit 1
fi

add_key() {
  # Remove any old copy first so running this twice never errors.
  /usr/libexec/PlistBuddy -c "Delete :$1" "$PLIST" >/dev/null 2>&1
  /usr/libexec/PlistBuddy -c "Add :$1 string '$2'" "$PLIST"
}

add_key NSLocationWhenInUseUsageDescription "Agricast needs your location to share your live position."
add_key NSPhotoLibraryUsageDescription "Agricast needs access to your photos so you can add pictures of your livestock."

# Android location permission (harmless if you only use iOS).
MANIFEST="android/app/src/main/AndroidManifest.xml"
if [ -f "$MANIFEST" ] && ! grep -q "ACCESS_FINE_LOCATION" "$MANIFEST"; then
  perl -0pi -e 's/<application/<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" \/>\n    <application/' "$MANIFEST"
fi

echo ""
echo "4/4  Checking the permission is really in the file..."
if /usr/libexec/PlistBuddy -c "Print :NSLocationWhenInUseUsageDescription" "$PLIST" >/dev/null 2>&1; then
  echo "     OK - location permission is set."
else
  echo "     FAILED - the location permission is NOT in $PLIST. Send me this message."
  exit 1
fi

echo ""
echo "=============================================================="
echo " DONE. Now do these two things:"
echo "  1) If the app is running, press q in its terminal to STOP it"
echo "     (hot reload will NOT pick up the permission)."
echo "  2) Start it fresh:"
echo "     flutter run -d 505D4F73-0AF0-421D-8D96-4FE0E262BF87 --dart-define=API_BASE_URL=http://localhost:5050"
echo "=============================================================="
