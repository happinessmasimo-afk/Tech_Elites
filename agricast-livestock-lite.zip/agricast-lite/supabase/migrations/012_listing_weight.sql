-- Adds an optional weight (kg) to a listing so buyers can filter by it.
alter table public.listings
  add column if not exists weight_kg numeric;

comment on column public.listings.weight_kg is 'Approximate live weight per animal, in kg. Optional.';

notify pgrst, 'reload schema';
