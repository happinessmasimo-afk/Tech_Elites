-- When a farmer declines an offer they must say why; the buyer sees it.
alter table public.listing_offers
  add column if not exists decline_reason text;

comment on column public.listing_offers.decline_reason is
  'Why the farmer declined this offer (required when status = declined).';

notify pgrst, 'reload schema';
