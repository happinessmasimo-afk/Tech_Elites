# Agricast Livestock — Lite

A slimmed-down rebuild of `agricast-livestock`: **farmer login/register/logout
+ marketplace only** (browse, create listings, buyer offers). Everything else
from the original app — animals register, health timeline, finance,
breeding, stakeholder portal, documents, notifications, AI insights — has
been deliberately left out.

Original stack → this stack:

| Layer     | Original                          | This project                          |
|-----------|------------------------------------|----------------------------------------|
| Mobile    | React Native (Expo Router)         | **Flutter**                            |
| Backend   | none (client called Supabase directly) | **ASP.NET Core Web API**          |
| Database/Auth | Supabase project A            | **New Supabase project** (you provide the keys) |

## How the pieces fit together

```
Flutter app  --https-->  ASP.NET Core API  --https-->  Supabase (Auth + Postgres/PostgREST)
```

The Flutter app never talks to Supabase directly — every request goes
through your ASP.NET API. That API:

- Proxies register/login/refresh/logout to **Supabase Auth** (`/auth/v1/...`).
- Proxies listings/offers reads & writes to **Supabase's REST API**
  (PostgREST, `/rest/v1/...`), always using the *calling user's own access
  token* — never the service-role key. That means Postgres row-level
  security (defined in `supabase/migrations/`) is what actually enforces
  "a farmer can only edit their own listings", "a buyer only sees their own
  offers", etc. — not application code, which mirrors how the original app
  worked, just moved server-side.
- Validates every incoming request's Bearer token by asking Supabase's Auth
  server "who is this?" (`GET /auth/v1/user`) — so this API never needs to
  know your project's JWT-signing setup at all.

This is the "simplest solid" option: it reuses Supabase's battle-tested auth
and the RLS policies already designed for this schema, instead of
reimplementing password hashing/session/JWT-signing logic from scratch in
C#.

## 1. Supabase — new project

1. Create a new project at supabase.com (or use one you already have that
   you're happy to dedicate to this).
2. In the SQL Editor, paste in and run **`supabase/migrations/RUN_ALL.sql`**
   — every migration through 010, concatenated into one file. Every
   statement in it is safe to run repeatedly (nothing will error or
   duplicate data if some of it already ran before), so this is the
   simplest way to guarantee your database is fully caught up: when in
   doubt, just run this whole file again. Its last few lines are a
   one-time manual step (promoting your farmer account) — read the
   comment there and run that one line yourself with your real email.
   (The individual numbered files still exist for reference if you want
   to see what changed and when.)
3. From **Project Settings → API**, grab:
   - **Project URL**
   - **anon / public** key (not the service_role key — this project
     intentionally never uses it)
4. (Optional) **Authentication → Providers → Email**: turn "Confirm email"
   off while you're testing, so signup logs a farmer straight in.

> You mentioned attaching your Supabase keys — they didn't come through
> with your message, so I've left placeholders. Drop them into
> `backend-aspnet/AgricastLivestock.Api/appsettings.json` (or as env vars —
> see `.env.example` in that folder) and everything else just works.

## 2. Backend — ASP.NET Core API

```bash
cd backend-aspnet/AgricastLivestock.Api
dotnet restore
dotnet run
```

Runs on `http://localhost:5050` by default (Swagger UI at `/swagger` in
Development). Set `Supabase:Url` / `Supabase:AnonKey` in
`appsettings.Development.json` or as environment variables
(`Supabase__Url`, `Supabase__AnonKey`) before running.

Endpoints:

| Method | Path                          | Auth?     | What                                |
|--------|-------------------------------|-----------|-------------------------------------|
| POST   | /api/auth/register             | no        | Sign up a farmer                    |
| POST   | /api/auth/login                | no        | Log in                              |
| POST   | /api/auth/refresh               | no        | Refresh an expired access token     |
| POST   | /api/auth/logout                | yes       | Log out                             |
| GET    | /api/auth/me                    | yes       | Current farmer's profile            |
| PUT    | /api/auth/me                    | yes       | Edit full name / phone / location    |
| GET    | /api/listings                   | no        | Browse active listings (guest OK)   |
| GET    | /api/listings/mine               | yes       | Your own listings (any status)      |
| GET    | /api/listings/{id}                | no        | One listing                         |
| POST   | /api/listings                   | yes       | Create a listing                    |
| PUT    | /api/listings/{id}                | yes       | Edit / mark sold / withdraw         |
| DELETE | /api/listings/{id}                | yes       | Delete                              |
| GET    | /api/listings/{id}/offers           | yes       | Offers on your listing              |
| POST   | /api/listings/{id}/offers           | yes       | Make an offer as a buyer (negotiable price) |
| POST   | /api/listings/{id}/buy-now          | yes       | Buy immediately at the asking price, no negotiation |
| GET    | /api/offers/mine                 | yes       | Offers you've made                  |
| PATCH  | /api/offers/{id}                  | yes       | Accept / decline / withdraw         |
| POST   | /api/uploads/listing-photo          | yes       | Upload one listing photo (multipart, field name `file`), returns `{url}` |
| GET    | /api/finance/summary               | yes       | Total revenue + list of your sold listings |
| POST   | /api/payments/dummy-pay           | yes       | Simulated payment for an accepted offer — marks it paid (triggers auto-sold) |
| POST   | /api/deliveries                    | yes       | Buyer records pickup or delivery choice (+ address if delivery) |
| GET    | /api/deliveries/by-offer/{offerId}   | yes       | Look up the delivery arrangement for an offer |
| GET    | /api/deliveries/{id}                 | yes       | One delivery's current state (polled by the tracking screen) |
| POST   | /api/deliveries/{id}/start              | yes       | The traveller (buyer for pickup, farmer for delivery) starts the trip |
| PATCH  | /api/deliveries/{id}/location          | yes       | The traveller pushes a live GPS fix, recomputes distance/ETA |
| PATCH  | /api/deliveries/{id}/status            | yes       | Mark a delivery `delivered` |

## Roles: one farmer, everyone else buyers

`profiles.role` is `'buyer'` by default for every signup. There is exactly
one way to become the farmer — a one-time manual SQL update (see
`005_roles.sql`) — never through the app itself. This is enforced two
places, not just hidden in the UI:
- **Database**: the `listings_insert_own` / `listings_update_own` /
  `listings_delete_own` RLS policies require `role = 'farmer'`, so a buyer
  calling the API directly still can't create or edit a listing.
- **App**: buyers never see "New listing", "My listings", or "Finance" —
  only "My offers", since browsing and making offers is all a buyer does.

## Maps (Mapbox)

Your Mapbox token is already wired in (`mobile-flutter/lib/config/api_config.dart`,
`MapConfig`). It's a public `pk.` token, safe to ship client-side — same
category as the Supabase anon key. Used for:
- A full-screen pin-drop picker when creating a listing ("Pin exact
  location on map", optional)
- A small static-look map on the listing detail page when a listing has
  coordinates

No native Mapbox SDK is linked in — this uses `flutter_map` fetching plain
Mapbox raster tiles over HTTPS, which avoids the native build headaches
`mapbox_gl` would add on top of everything else already in this project.

## Payments (dummy checkout — no real gateway)

Per your request, no real payment provider — this is a fully simulated,
end-to-end checkout so the *flow* looks and works like a real one:

1. Buyer's offer gets accepted by the farmer.
2. "Pay now (demo checkout)" appears on the buyer's My Offers screen.
3. **Order summary** → **card details** (any values — nothing is validated
   as a real card, only the last 4 digits get sent along for display) →
   **"Processing payment..."** (a deliberate ~1.2s delay, so it doesn't
   feel instant/fake) → **success**.
4. On success, a database trigger (`008_auto_sold_on_payment.sql`)
   automatically marks the listing **sold** and records the sale price —
   this is what makes it show up as sold for the farmer and in Finance
   without the app needing a second "now mark it sold" step anywhere.
5. Buyer is then walked straight into choosing pickup or delivery (below).

No external network call happens anywhere in this flow — it's a one-line
toggle on the backend (`PaymentsController.DummyPay`), by design.

## Delivery & live tracking (Mapbox) — works like e-hailing, both directions

After paying, the buyer picks one of:
- **"I'll collect it myself"** (pickup) — the **buyer** is the one who
  travels, to the farm.
- **"Farmer delivers to me"** (delivery) — the **farmer** is the one who
  travels, to the buyer's pinned address.

Whichever side is travelling gets `TripTravelerScreen`; whichever side
isn't gets `TripWatchScreen`. Same e-hailing shape either way:

1. **Trip created** — for delivery, the buyer pins their address first
   (via the map, see below) and the app immediately computes real driving
   distance/ETA via Mapbox's Directions API between the farm and that
   address. For pickup, no upfront address is needed — the traveller's
   position simply isn't known yet.
2. **Traveller taps Start** — flips the trip to "in transit" immediately.
   The other side's screen is already polling the same delivery, so this
   is the "notification" moment — next time their screen refreshes
   (within ~6 seconds) they see it change from "waiting" to "on the way".
3. **Live tracking while en route** — the traveller's real device GPS
   streams to the backend every time they move roughly 100m; each update
   recomputes distance/ETA via Mapbox. The watching side's map shows that
   marker moving in near-real-time, with live distance/ETA text below it.
4. **Traveller marks it finished** ("Mark picked up" / "Mark as
   delivered") — the other side sees this the moment their screen next
   polls.

The pin-drop map (used both for a delivery address and when a farmer sets
a listing's location) has three ways to set a spot:
- **Drag the map** — the pin stays centered, the map moves under it.
- **Type an address** — autocomplete suggestions appear after 3
  characters, via Mapbox's real Geocoding API (debounced so it doesn't
  fire a request per keystroke). A failed search shows the real reason as
  red text under the search bar rather than just silently finding nothing.
- **Tap the location button** (bottom-right, small circular button) — uses
  the device's actual GPS position via `geolocator`.

This needs a location permission that lives in files this zip can't
include (same reason as the photo-picker permission earlier). **Manual
XML editing is easy to get wrong or lose** (e.g. re-running `flutter
create .` regenerates `Info.plist` from scratch, silently wiping a manual
edit) — run this one command instead, from `mobile-flutter/`, every time
after `flutter create .`:

**iOS:**
```bash
/usr/libexec/PlistBuddy -c "Add :NSLocationWhenInUseUsageDescription string 'Agricast Livestock needs your location to share your live position with a buyer while delivering their order.'" ios/Runner/Info.plist
```
If it says the key already exists, that's fine — it means it's already set. Verify any time with:
```bash
/usr/libexec/PlistBuddy -c "Print :NSLocationWhenInUseUsageDescription" ios/Runner/Info.plist
```

**Android** — this one can't be added with a one-liner the same way; edit
`mobile-flutter/android/app/src/main/AndroidManifest.xml` and add, inside
the outer `<manifest>` tag, alongside `<application>`:
```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

Full stop/restart `flutter run` after either change — hot reload won't
pick up native manifest/plist edits.

**If you still see "Permission definitions not found in the app's
Info.plist"** after running the PlistBuddy command, it means `flutter
create .` was run *after* that command and overwrote it again — re-run
the command, then restart `flutter run` without regenerating platform
folders again in between.

## Buying: two paths, both always available

- **Buy Now** — buys immediately at the listed asking price, skipping
  negotiation entirely. Straight into the dummy checkout.
- **Make an offer** — negotiate a different price; the farmer can accept,
  decline, or the buyer can withdraw. Only once the farmer accepts does
  "Pay now" appear for that offer.

Both buttons always show together on an active listing (for anyone who
isn't its owner) — Buy Now was added without removing or replacing
Make an Offer.

Profile (name, phone, location) is editable by the account holder any
time via the pencil icon on the Profile screen — set your location to
whatever you want it to say, it's a free-text field, not tied to GPS.

## Finance

Marking a listing "sold" (from the app's "My listings" screen) prompts for
the actual sale price, which is stored on `listings.sold_price` /
`listings.sold_at`. The Finance screen sums `sold_price` (falling back to
`asking_price` if a listing predates this field) across all of a farmer's
own sold listings — RLS already scopes this to "your own", so there's no
extra filtering needed server-side.

## 3. Mobile — Flutter app

The `lib/` folder and `pubspec.yaml` are hand-written; run this once to
generate the platform (`android/`, `ios/`) folders Flutter needs:

```bash
cd mobile-flutter
flutter create --project-name agricast_livestock_lite .
flutter pub get
```

(`flutter create .` on an existing folder fills in the missing platform
scaffolding without touching your `lib/` or `pubspec.yaml`.)

Point it at your running API:

```bash
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:5050   # Android emulator
flutter run --dart-define=API_BASE_URL=http://localhost:5050  # iOS simulator
```

Screens included: splash (session check) → login / register → marketplace
browse (guest-accessible) → listing detail → make an offer → my listings
(mark sold / withdraw) → my offers (withdraw) → profile (logout).

**"Could not find the 'X' column of 'Y' in the schema cache" (PGRST204) when saving anything**

This means a migration that adds that column was never actually run on
your Supabase project — it's not a code bug, PostgREST is correctly
telling you the column genuinely doesn't exist yet in your database. Run
**`RUN_ALL.sql`** (it's safe to re-run in full any time) and this
resolves itself. Every migration since this was first hit also ends with
`notify pgrst, 'reload schema';`, which forces PostgREST to notice new
columns immediately rather than waiting on its own cache refresh.

**"Could not start delivery tracking: Listing not found" / "Could not
save your choice: Listing not found" / a bought or sold listing 404s**

Fixed by `010_listing_visibility_for_buyers.sql` (included in
`RUN_ALL.sql`) plus a Flutter-side fix already in this codebase. If you
still see this exact error, it means `RUN_ALL.sql` hasn't actually been
run against your Supabase project yet — run it and this should disappear.
Root cause was two-fold: (1) once a listing's status leaves `active`, the
database's row-level security correctly hides it from anyone except its
owner — including the buyer who actually bought it, which broke both
viewing that listing again and arranging its delivery; (2) separately, the
app's own listing-detail and marketplace-browse calls were hardcoded to
never send your login token at all (even when logged in), which is why
even a farmer viewing their *own* sold listing hit the same 404.

**Address search in the location picker shows no suggestions**

Earlier versions of this silently swallowed every possible failure (bad
token, network error, rate limit) and just showed "no results", which
looks identical to "this address doesn't exist" with no way to tell
which one it actually was. Fixed: a failed search now shows the real
reason as red text under the search bar instead of just going quiet. If
you see an error there now, it'll tell you what actually happened
(network issue, Mapbox rejecting the request, etc.) — send me that exact
text if it's still not finding real places.

**Every single request returns a bare `403` — register, login, browsing listings, all of it**

This is almost always **macOS's built-in AirPlay Receiver**, not Supabase or
your code. AirPlay Receiver listens on port 5000 by default (macOS Monterey
and later), and answers *any* request on that port — regardless of path —
with a plain 403, before your ASP.NET app ever sees it. If you see a 403
with no error message on a request that your own controller code couldn't
possibly return 403 for, this is why.

Fixed already in this version by moving the API to **port 5050** instead
(`Urls` in `appsettings.json`, and the Flutter default in `api_config.dart`).
If you still see it, either something else is on port 5050 too, or you're
running an older build — try:
```bash
lsof -i :5050        # see what's bound to the port
```
or turn off AirPlay Receiver entirely: System Settings → General → AirDrop
& Handoff → AirPlay Receiver → off.

**Photo picker crashes or does nothing on iOS ("Add photos" button)**

iOS requires an explicit permission-usage description before any app can
open the photo library — without it, `image_picker` fails silently or the
OS kills the app. Since `ios/Runner/Info.plist` is generated locally by
`flutter create .` (not part of this zip), add this key yourself, once:

Open `mobile-flutter/ios/Runner/Info.plist`, and inside the outer `<dict>`
add:
```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>Agricast Livestock needs access to your photos so you can add pictures of your livestock to a listing.</string>
```
Then do a full stop/restart of `flutter run` (hot reload won't pick up
Info.plist changes).


**`ClientException ... Operation not permitted, errno = 1` when running on macOS desktop**

This means `flutter run` picked the **macOS (desktop)** target instead of a
simulator/emulator. macOS's App Sandbox blocks all outgoing network
connections by default for desktop apps — that includes calls to your
ASP.NET API on `localhost`. It's not a bug in the app; every fresh Flutter
macOS project needs this entitlement turned on explicitly.

Fix: see `mobile-flutter/macos-entitlements-fix/README.md` — copy two small
files over the ones `flutter create .` generates, or just run on the iOS
Simulator / an Android emulator instead, which don't have this restriction:
```bash
open -a Simulator
flutter run --dart-define=API_BASE_URL=http://localhost:5050
```

**Fonts fail to load / "Failed to load font" errors**

Earlier versions of this project fetched Plus Jakarta Sans and Manrope over
the network at runtime (`google_fonts` package), which hit the same macOS
sandbox restriction above. Both fonts are now bundled locally under
`assets/fonts/` and declared in `pubspec.yaml` — no network needed to render
text at all, regardless of platform.

## Notes / things you'll likely want to change next

- **Photos**: `listings.photo_urls` and a `listing-photos` storage bucket are
  in the schema, but upload wiring (picking an image in Flutter → uploading
  to Supabase Storage via the API) isn't built yet — happy to add it.
- **Email confirmation**: if you leave Supabase's "confirm email" on,
  `register` returns `requiresEmailConfirmation: true` and the Flutter app
  just shows a message and sends the farmer back to login — there's no
  in-app "check your email" deep link handling yet.
- The ASP.NET project targets **.NET 8**; adjust the `TargetFramework` in
  the `.csproj` if you're on a different SDK.
