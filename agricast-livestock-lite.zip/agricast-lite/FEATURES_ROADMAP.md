# Feature roadmap — what real livestock-trading platforms do

Researched a handful of platforms actually operating in this space —
Breedr (UK, traded £1.85m+ of cattle through their app), Farm Fayre
(Ireland), and FarmGate Auctions (Australia) — to see what makes a
livestock marketplace feel complete rather than just "a form and a list".
Below: what's now built into this app, and what's genuinely worth adding
next, roughly in the order it'd pay off.

## Already built (this update)

- Farmer dashboard with real stats (active listings, revenue, sold count,
  pending offers) and quick actions
- Farmer/buyer role split enforced at the database level
- Offers received screen for the farmer with accept/decline
- Sold-listing tracking feeding a real revenue total (Finance)
- Multi-photo listings
- Map location picking + display (Mapbox)
- A dummy end-to-end checkout (order summary → card form → processing →
  success) that automatically marks the listing sold and updates Finance
  via a database trigger the instant "payment" completes
- Pickup vs. delivery choice after a sale, with real Mapbox-computed
  distance/ETA and live GPS tracking of the farmer's position on the way

## Worth adding next, and why

**1. Movement/health history attached to a listing.**
Breedr's single biggest lever on price was exactly this: listings with
verified weight, movement, and medicine history sold for ~£100/head more
on average than a guess-and-negotiate sale, because buyers trust a record
they didn't have to take on faith. Nothing about our schema stops adding
a `listing_events` table (vaccinations, weigh-ins, movements) a farmer can
attach to a listing before publishing it.

**2. Bidding, not just fixed-price offers.**
Farm Fayre's whole pitch is visible, real-time bidding with a reserve
price rather than one-shot offers. Given we already have `listing_offers`,
this is closer than it looks: allow multiple offers per listing to coexist
(already possible), show all bids to everyone watching the listing (not
just the farmer), and let the farmer set a reserve.

**3. Escrow-style payment timing.**
Farm Fayre holds payment until the animal is actually delivered and the
buyer has a short window to raise issues, rather than releasing funds the
moment a card is charged. Yoco doesn't do escrow natively, but the
`payment_status` column already added here could grow a third state
(`held` → `released`) with release triggered manually by the farmer
confirming delivery, without needing a different payment provider.

**4. Delivery/collection coordination.**
Even just a "how will this be collected" field and a delivery-date picker
on an accepted offer would close a real gap — right now the app's job
ends at payment, but the actual sale doesn't.

**5. Push notifications.**
A buyer offering on a listing, or a farmer accepting an offer, are both
moments where the other side is currently expected to just check the app.
Supabase has a notifications-friendly setup (Edge Functions + a device
token table) that would fit this stack without adding a new vendor.

**6. Search & filters on the marketplace browse screen.**
Right now it's one flat list. Species/breed/price-range filters and a
text search are cheap relative to how much they'd help once there's more
than a handful of listings.

**7. Verified farmer badge / ratings.**
Since this app is single-farmer by design right now, this matters less
today — but if it ever grows past one farmer, buyer trust signals (a
review after a completed sale, a "verified" badge) are what every
platform researched leans on to replace the trust a real-life auction
mart provides face to face.

None of the above needed guessing at fake data — Mapbox (location picking,
distance/ETA, live tracking) uses your real key against the real API.
Payment is intentionally a dummy simulation per your instruction, not a
placeholder for a missing integration.
